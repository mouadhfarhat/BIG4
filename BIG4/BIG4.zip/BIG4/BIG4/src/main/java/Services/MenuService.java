package Services;
import Entities.Menu;
import Utils.Mydatabase;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class MenuService {
    private final Connection cnx;

    public MenuService() {
        try {
            cnx = Mydatabase.getInstance().getConnection();
        } catch (SQLException e) {
            throw new IllegalStateException("Unable to obtain database connection", e);
        }
    }
    /*public void addMenu(Menu menu) throws SQLException{
        String sql = "insert into menu (title, description, isActive) " +
                "values ('" + menu.getTitle() + "', '" +
                menu.getDescription() + "', " +
                menu.isActive() + ")";
        Statement st = cnx.createStatement();
        st.executeUpdate(sql);
    }*/
    public void addMenu2(Menu menu) throws SQLException {
        String sql = "insert into menu (title , description , isActive)" + "values(?,?,?)";
        PreparedStatement ps = cnx.prepareStatement(sql);
        ps.setString(1, menu.getTitle());
        ps.setString(2, menu.getDescription());
        ps.setBoolean(3, menu.isActive());
        ps.executeUpdate();
    }
    public void updateMenu(Menu menu) throws SQLException
    {
        String sql = "update menu set title = ? , description = ? , isActive = ? where id = ?";
        PreparedStatement ps = cnx.prepareStatement(sql);
        ps.setString(1, menu.getTitle());
        ps.setString(2, menu.getDescription());
        ps.setBoolean(3, menu.isActive());
        ps.setInt(4, menu.getId());
        ps.executeUpdate();

    }
    public Menu getById(int id) throws SQLException {

        String sql = "SELECT * FROM menu WHERE id = ?";
        PreparedStatement ps = cnx.prepareStatement(sql);
        ps.setInt(1, id);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            Menu m = new Menu();
            m.setId(rs.getInt("id"));
            m.setTitle(rs.getString("title"));
            m.setDescription(rs.getString("description"));
            m.setActive(rs.getBoolean("isActive"));
            return m;
        }

        return null; // if no row found
    }




    public List<Menu> getallMenu() throws SQLException {
        List<Menu> Menus = new ArrayList<>();
        String sql = "select * from Menu";
        Statement st = cnx.createStatement();
        ResultSet rs = st.executeQuery(sql);
        while (rs.next()) {
            Menu p = new Menu();
            p.setId(rs.getInt("id"));
            p.setTitle(rs.getString("title"));
            p.setDescription(rs.getString("description"));
            p.setActive(rs.getBoolean("isActive"));
            Menus.add(p);
        }

        return Menus;
    }
    public void delete(int id) throws SQLException {

        String sql = "DELETE FROM menu WHERE id = ?";
        PreparedStatement ps = cnx.prepareStatement(sql);
        ps.setInt(1, id);

        ps.executeUpdate();
    }

}
