package Controllers;

import Entities.Fooddonationevent;
import Entities.FoodDonationItem;
import Services.FoodDonationItemService;
import Services.EventRatingService;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

public class EventDetailsPageController {

    // ── Event info ────────────────────────────────────────────────────────────
    @FXML private Label eventDateLabel;
    @FXML private Label charityNameLabel;
    @FXML private Label statusBadge;
    @FXML private Label dateValueLabel;
    @FXML private Label totalItemsLabel;
    @FXML private Label deliveryIdLabel;
    @FXML private VBox  dishesContainer;
    @FXML private Label totalPortionsLabel;

    // ── Average rating display ────────────────────────────────────────────────
    @FXML private Label avgEventStarsLabel;
    @FXML private Label avgEventScoreLabel;
    @FXML private Label avgFoodStarsLabel;
    @FXML private Label avgFoodScoreLabel;
    @FXML private Label ratingCountLabel;
    @FXML private VBox  reviewsContainer;

    // ── Rating form ───────────────────────────────────────────────────────────
    @FXML private VBox     ratingFormBox;
    @FXML private Label    alreadyRatedLabel;
    @FXML private Button   estar1, estar2, estar3, estar4, estar5;
    @FXML private Button   fstar1, fstar2, fstar3, fstar4, fstar5;
    @FXML private TextArea commentArea;
    @FXML private Label    ratingStatusLabel;

    // ── State ─────────────────────────────────────────────────────────────────
    private Fooddonationevent  currentEvent;
    private EventRatingService ratingService = new EventRatingService();
    private int selectedEventStars = 0;
    private int selectedFoodStars  = 0;

    // TODO: replace with your session/auth user ID
    private int currentUserId = 1;

    private static final String STAR_ON  = "-fx-background-color:transparent;-fx-text-fill:#FFA726;-fx-font-size:28px;-fx-padding:0;-fx-cursor:hand;";
    private static final String STAR_OFF = "-fx-background-color:transparent;-fx-text-fill:#ccc;-fx-font-size:28px;-fx-padding:0;-fx-cursor:hand;";

    // ── Entry point ───────────────────────────────────────────────────────────
    public void setEvent(Fooddonationevent event) {
        this.currentEvent = event;
        populateEventInfo();
        loadDishes();
        loadRatingStats();
        loadReviews();
        checkAlreadyRated();
    }

    // ── Event info ────────────────────────────────────────────────────────────
    private void populateEventInfo() {
        if (currentEvent == null) return;
        String dateStr = "—";
        if (currentEvent.getEventDate() != null)
            dateStr = currentEvent.getEventDate().toLocalDate()
                .format(DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy", Locale.ENGLISH));
        eventDateLabel.setText(dateStr);
        charityNameLabel.setText("🏛️  " + currentEvent.getCharityName());
        dateValueLabel.setText(dateStr);
        totalItemsLabel.setText(currentEvent.getTotalQuantity() + " items");
        deliveryIdLabel.setText(currentEvent.getDeliveryId() != null
            ? "#" + currentEvent.getDeliveryId() : "N/A");
        String status = currentEvent.getStatus() != null ? currentEvent.getStatus() : "UNKNOWN";
        statusBadge.setText(status.toUpperCase());
        statusBadge.setStyle(
            "-fx-font-size:13px;-fx-font-weight:bold;-fx-padding:6 18;" +
            "-fx-background-radius:20;-fx-background-color:" + statusBg(status) +
            ";-fx-text-fill:" + statusColor(status) + ";");
    }

    // ── Dishes ────────────────────────────────────────────────────────────────
    private void loadDishes() {
        dishesContainer.getChildren().clear();
        int total = 0;
        try {
            FoodDonationItemService svc = new FoodDonationItemService();
            List<FoodDonationItem> items = svc.getItemsByEventId(currentEvent.getDonationEventId());
            if (items == null || items.isEmpty()) {
                Label e = new Label("No dishes listed for this event.");
                e.setStyle("-fx-text-fill:#999;-fx-font-size:13px;-fx-padding:10 0 10 0;");
                dishesContainer.getChildren().add(e);
            } else {
                for (FoodDonationItem item : items) {
                    dishesContainer.getChildren().add(buildDishRow(item.getItemName(), item.getQuantity()));
                    total += item.getQuantity();
                }
            }
        } catch (SQLException e) {
            Label err = new Label("⚠️ " + e.getMessage());
            err.setStyle("-fx-text-fill:#f44336;-fx-font-size:12px;");
            dishesContainer.getChildren().add(err);
        }
        totalPortionsLabel.setText(total + " portions");
    }

    private HBox buildDishRow(String name, int qty) {
        HBox row = new HBox();
        row.setAlignment(Pos.CENTER_LEFT);
        row.setPadding(new Insets(12, 16, 12, 16));
        row.setStyle("-fx-background-color:#fafafa;-fx-border-color:#f0f0f0;-fx-border-width:0 0 1 0;");
        Label icon = new Label("🍽️");
        icon.setStyle("-fx-font-size:16px;");
        icon.setPadding(new Insets(0, 12, 0, 0));
        Label nameLbl = new Label(name);
        nameLbl.setStyle("-fx-text-fill:#333;-fx-font-size:14px;-fx-font-weight:bold;");
        Region spacer = new Region(); HBox.setHgrow(spacer, Priority.ALWAYS);
        Label qtyLbl = new Label(qty + " portions");
        qtyLbl.setStyle("-fx-text-fill:#FF9800;-fx-font-size:13px;-fx-font-weight:bold;");
        row.getChildren().addAll(icon, nameLbl, spacer, qtyLbl);
        return row;
    }

    // ── Rating stats ──────────────────────────────────────────────────────────
    private void loadRatingStats() {
        int eventId     = currentEvent.getDonationEventId();
        double avgEvent = ratingService.getAverageEventRating(eventId);
        double avgFood  = ratingService.getAverageFoodRating(eventId);
        int    count    = ratingService.getRatingCount(eventId);
        if (count == 0) {
            avgEventStarsLabel.setText("☆☆☆☆☆");
            avgEventScoreLabel.setText("No ratings yet");
            avgFoodStarsLabel.setText("☆☆☆☆☆");
            avgFoodScoreLabel.setText("No ratings yet");
            ratingCountLabel.setText("Be the first to rate!");
        } else {
            avgEventStarsLabel.setText(buildStarString(avgEvent));
            avgEventScoreLabel.setText(String.format("%.1f / 5.0", avgEvent));
            avgFoodStarsLabel.setText(buildStarString(avgFood));
            avgFoodScoreLabel.setText(String.format("%.1f / 5.0", avgFood));
            ratingCountLabel.setText(count + " review" + (count == 1 ? "" : "s"));
        }
    }

    // ── Load reviews with CRUD buttons ───────────────────────────────────────
    private void loadReviews() {
        reviewsContainer.getChildren().clear();
        List<EventRatingService.RatingRow> rows =
            ratingService.getRatingsWithComments(currentEvent.getDonationEventId());

        if (rows.isEmpty()) {
            Label none = new Label("No reviews yet. Be the first!");
            none.setStyle("-fx-text-fill:#aaa;-fx-font-size:13px;-fx-font-style:italic;-fx-padding:10 16;");
            reviewsContainer.getChildren().add(none);
            return;
        }

        for (EventRatingService.RatingRow r : rows) {
            VBox card = new VBox(6);
            card.setPadding(new Insets(14, 16, 14, 16));
            card.setStyle("-fx-background-color:#fafafa;-fx-border-color:#f0f0f0;-fx-border-width:0 0 1 0;");

            // Top row: user + date + edit/delete buttons (only for current user)
            HBox topRow = new HBox(10);
            topRow.setAlignment(Pos.CENTER_LEFT);
            String user = r.userEmail != null ? r.userEmail.split("@")[0] : "Anonymous";
            Label userLbl = new Label("👤 " + user);
            userLbl.setStyle("-fx-text-fill:#1a3a6b;-fx-font-size:13px;-fx-font-weight:bold;");
            Region sp = new Region(); HBox.setHgrow(sp, Priority.ALWAYS);
            String date = r.createdAt != null && r.createdAt.length() >= 10
                ? r.createdAt.substring(0, 10) : "";
            Label dateLbl = new Label(date);
            dateLbl.setStyle("-fx-text-fill:#aaa;-fx-font-size:11px;");
            topRow.getChildren().addAll(userLbl, sp, dateLbl);

            // Edit + Delete only for current user's review
            if (r.userId == currentUserId) {
                Button editBtn = new Button("✏️ Edit");
                editBtn.setStyle("-fx-background-color:#e3f2fd;-fx-text-fill:#1565c0;" +
                    "-fx-font-size:11px;-fx-padding:4 10;-fx-background-radius:4;-fx-cursor:hand;");

                Button deleteBtn = new Button("🗑️ Delete");
                deleteBtn.setStyle("-fx-background-color:#ffebee;-fx-text-fill:#c62828;" +
                    "-fx-font-size:11px;-fx-padding:4 10;-fx-background-radius:4;-fx-cursor:hand;");

                editBtn.setOnAction(ev -> showEditDialog(r));
                deleteBtn.setOnAction(ev -> confirmDelete(r));

                topRow.getChildren().addAll(editBtn, deleteBtn);
            }

            // Stars
            HBox starsRow = new HBox(16);
            starsRow.setAlignment(Pos.CENTER_LEFT);
            Label eStars = new Label("🎪 " + buildStarString(r.eventRating));
            eStars.setStyle("-fx-text-fill:#FFA726;-fx-font-size:14px;");
            Label fStars = new Label("🍽️ " + buildStarString(r.foodRating));
            fStars.setStyle("-fx-text-fill:#4CAF50;-fx-font-size:14px;");
            starsRow.getChildren().addAll(eStars, fStars);

            card.getChildren().addAll(topRow, starsRow);

            // Comment
            if (r.comment != null && !r.comment.isBlank()) {
                Label commentLbl = new Label("💬 " + r.comment);
                commentLbl.setWrapText(true);
                commentLbl.setStyle("-fx-text-fill:#555;-fx-font-size:13px;-fx-font-style:italic;");
                card.getChildren().add(commentLbl);
            }

            reviewsContainer.getChildren().add(card);
        }
    }

    // ── Edit dialog ───────────────────────────────────────────────────────────
    private void showEditDialog(EventRatingService.RatingRow r) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Edit Your Review");
        dialog.setHeaderText("Update your rating for this event");

        // Event stars
        Label eLabel = new Label("🎪 Event Rating:");
        eLabel.setStyle("-fx-font-weight:bold;");
        HBox eStarsBox = buildDialogStars(new int[]{r.eventRating});
        Button[] eStarBtns = (Button[]) eStarsBox.getUserData();

        // Food stars
        Label fLabel = new Label("🍽️ Food Rating:");
        fLabel.setStyle("-fx-font-weight:bold;");
        int[] foodVal = {r.foodRating};
        HBox fStarsBox = buildDialogStars(foodVal);
        Button[] fStarBtns = (Button[]) fStarsBox.getUserData();

        // Comment
        Label cLabel = new Label("💬 Comment:");
        cLabel.setStyle("-fx-font-weight:bold;");
        TextArea commentField = new TextArea(r.comment != null ? r.comment : "");
        commentField.setPrefRowCount(3);
        commentField.setWrapText(true);

        VBox content = new VBox(10, eLabel, eStarsBox, fLabel, fStarsBox, cLabel, commentField);
        content.setPadding(new Insets(16));
        content.setPrefWidth(400);
        dialog.getDialogPane().setContent(content);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        // Style OK button
        dialog.getDialogPane().lookupButton(ButtonType.OK)
            .setStyle("-fx-background-color:#FFA726;-fx-text-fill:white;-fx-font-weight:bold;");

        dialog.showAndWait().ifPresent(result -> {
            if (result == ButtonType.OK) {
                int newEStars = getSelectedFromBtns(eStarBtns);
                int newFStars = getSelectedFromBtns(fStarBtns);
                if (newEStars == 0 || newFStars == 0) {
                    showStatus("❌ Please select both ratings!", "#f44336");
                    return;
                }
                boolean ok = ratingService.updateRating(
                    r.ratingId, newEStars, newFStars, commentField.getText().trim());
                if (ok) {
                    loadRatingStats();
                    loadReviews();
                    checkAlreadyRated();
                    showStatus("✅ Review updated!", "#4CAF50");
                } else {
                    showStatus("❌ Update failed.", "#f44336");
                }
            }
        });
    }

    private HBox buildDialogStars(int[] valueHolder) {
        Button[] btns = new Button[5];
        HBox box = new HBox(4);
        for (int i = 1; i <= 5; i++) {
            Button b = new Button("★");
            final int val = i;
            b.setStyle(i <= valueHolder[0]
                ? "-fx-background-color:transparent;-fx-text-fill:#FFA726;-fx-font-size:26px;-fx-padding:0;-fx-cursor:hand;"
                : "-fx-background-color:transparent;-fx-text-fill:#ccc;-fx-font-size:26px;-fx-padding:0;-fx-cursor:hand;");
            b.setOnAction(ev -> {
                valueHolder[0] = val;
                for (int j = 0; j < 5; j++)
                    btns[j].setStyle(j < val
                        ? "-fx-background-color:transparent;-fx-text-fill:#FFA726;-fx-font-size:26px;-fx-padding:0;-fx-cursor:hand;"
                        : "-fx-background-color:transparent;-fx-text-fill:#ccc;-fx-font-size:26px;-fx-padding:0;-fx-cursor:hand;");
            });
            btns[i-1] = b;
            box.getChildren().add(b);
        }
        box.setUserData(btns);
        return box;
    }

    private int getSelectedFromBtns(Button[] btns) {
        int count = 0;
        for (Button b : btns)
            if (b.getStyle().contains("#FFA726")) count++;
        return count;
    }

    // ── Delete confirm ────────────────────────────────────────────────────────
    private void confirmDelete(EventRatingService.RatingRow r) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Delete Review");
        alert.setHeaderText("Are you sure?");
        alert.setContentText("This will permanently delete your review.");
        alert.getButtonTypes().setAll(ButtonType.YES, ButtonType.CANCEL);
        alert.showAndWait().ifPresent(result -> {
            if (result == ButtonType.YES) {
                boolean ok = ratingService.deleteRating(r.ratingId);
                if (ok) {
                    loadRatingStats();
                    loadReviews();
                    checkAlreadyRated(); // allow re-rating after delete
                    showStatus("🗑️ Review deleted.", "#888");
                } else {
                    showStatus("❌ Delete failed.", "#f44336");
                }
            }
        });
    }

    // ── Already rated ─────────────────────────────────────────────────────────
    private void checkAlreadyRated() {
        boolean rated = ratingService.hasUserRated(currentEvent.getDonationEventId(), currentUserId);
        ratingFormBox.setVisible(!rated);
        ratingFormBox.setManaged(!rated);
        alreadyRatedLabel.setVisible(rated);
        alreadyRatedLabel.setManaged(rated);
        if (!rated) { setEventStars(0); setFoodStars(0); commentArea.clear(); }
    }

    // ── Star buttons ──────────────────────────────────────────────────────────
    @FXML private void handleEStar1() { setEventStars(1); }
    @FXML private void handleEStar2() { setEventStars(2); }
    @FXML private void handleEStar3() { setEventStars(3); }
    @FXML private void handleEStar4() { setEventStars(4); }
    @FXML private void handleEStar5() { setEventStars(5); }

    private void setEventStars(int n) {
        selectedEventStars = n;
        estar1.setStyle(n >= 1 ? STAR_ON : STAR_OFF);
        estar2.setStyle(n >= 2 ? STAR_ON : STAR_OFF);
        estar3.setStyle(n >= 3 ? STAR_ON : STAR_OFF);
        estar4.setStyle(n >= 4 ? STAR_ON : STAR_OFF);
        estar5.setStyle(n >= 5 ? STAR_ON : STAR_OFF);
    }

    @FXML private void handleFStar1() { setFoodStars(1); }
    @FXML private void handleFStar2() { setFoodStars(2); }
    @FXML private void handleFStar3() { setFoodStars(3); }
    @FXML private void handleFStar4() { setFoodStars(4); }
    @FXML private void handleFStar5() { setFoodStars(5); }

    private void setFoodStars(int n) {
        selectedFoodStars = n;
        fstar1.setStyle(n >= 1 ? STAR_ON : STAR_OFF);
        fstar2.setStyle(n >= 2 ? STAR_ON : STAR_OFF);
        fstar3.setStyle(n >= 3 ? STAR_ON : STAR_OFF);
        fstar4.setStyle(n >= 4 ? STAR_ON : STAR_OFF);
        fstar5.setStyle(n >= 5 ? STAR_ON : STAR_OFF);
    }

    // ── Submit ────────────────────────────────────────────────────────────────
    @FXML
    private void handleSubmitRating() {
        if (selectedEventStars == 0) { showStatus("❌ Please rate the event!", "#f44336"); return; }
        if (selectedFoodStars  == 0) { showStatus("❌ Please rate the food!", "#f44336"); return; }
        boolean ok = ratingService.addRating(
            currentEvent.getDonationEventId(), currentUserId,
            selectedEventStars, selectedFoodStars, commentArea.getText().trim());
        if (ok) {
            ratingFormBox.setVisible(false);
            ratingFormBox.setManaged(false);
            alreadyRatedLabel.setVisible(true);
            alreadyRatedLabel.setManaged(true);
            loadRatingStats();
            loadReviews();
        } else {
            showStatus("❌ Failed to submit. Please try again.", "#f44336");
        }
    }

    private void showStatus(String msg, String color) {
        ratingStatusLabel.setText(msg);
        ratingStatusLabel.setStyle("-fx-text-fill:" + color + ";-fx-font-size:13px;");
    }

    // ── Back ──────────────────────────────────────────────────────────────────
    @FXML
    private void handleBack() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/client-events-calendar-api.fxml"));
            Stage stage = (Stage) charityNameLabel.getScene().getWindow();
            stage.setScene(new Scene(root, 1400, 800));
            stage.setMaximized(true);
        } catch (IOException e) { e.printStackTrace(); }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private String buildStarString(double avg) {
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= 5; i++) sb.append(i <= Math.round(avg) ? "★" : "☆");
        return sb.toString();
    }
    private String statusColor(String s) {
        switch (s.toUpperCase()) {
            case "COMPLETED":   return "#4CAF50";
            case "IN_PROGRESS": return "#2196F3";
            case "SCHEDULED":   return "#9C27B0";
            case "CANCELLED":   return "#f44336";
            default:            return "#FF9800";
        }
    }
    private String statusBg(String s) {
        switch (s.toUpperCase()) {
            case "COMPLETED":   return "#e8f5e9";
            case "IN_PROGRESS": return "#e3f2fd";
            case "SCHEDULED":   return "#f3e5f5";
            case "CANCELLED":   return "#ffebee";
            default:            return "#fff3e0";
        }
    }
}
