package Controllers;

import Services.NotificationService;
import Utils.Mydatabase;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.geometry.Insets;

import java.sql.*;
import java.time.format.DateTimeFormatter;

/**
 * NotificationsController
 * Shows the user's notifications in a panel/tab
 */
public class NotificationsController {

    @FXML private VBox notificationsContainer;
    @FXML private Label unreadCountLabel;
    @FXML private Button markAllReadBtn;

    private final NotificationService notificationService = NotificationService.getInstance();
    private int currentUserId = 1; // Replace with session user

    private static final DateTimeFormatter DATE_FMT =
            DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm");

    @FXML
    public void initialize() {
        loadNotifications();
    }

    public void setCurrentUserId(int userId) {
        this.currentUserId = userId;
        loadNotifications();
    }

    @FXML
    private void handleMarkAllRead() {
        String sql = "UPDATE notifications SET is_read = 1 WHERE user_id = ?";
        try (Connection conn = Mydatabase.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, currentUserId);
            ps.executeUpdate();
            loadNotifications();
        } catch (SQLException e) {
            System.err.println("[NotificationsController] Error: " + e.getMessage());
        }
    }

    @FXML
    private void handleRefresh() {
        loadNotifications();
    }

    private void loadNotifications() {
        if (notificationsContainer == null) return;
        notificationsContainer.getChildren().clear();

        String sql = """
                SELECT n.notification_id, n.message, n.notification_type,
                       n.status, n.is_read, n.created_at, n.sent_at
                FROM notifications n
                WHERE n.user_id = ?
                ORDER BY n.created_at DESC
                LIMIT 50
                """;

        int unread = 0;

        try (Connection conn = Mydatabase.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, currentUserId);
            ResultSet rs = ps.executeQuery();

            boolean hasAny = false;
            while (rs.next()) {
                hasAny = true;
                int notifId    = rs.getInt("notification_id");
                String message = rs.getString("message");
                String type    = rs.getString("notification_type");
                String status  = rs.getString("status");
                boolean isRead = rs.getBoolean("is_read");
                Timestamp createdAt = rs.getTimestamp("created_at");

                if (!isRead) unread++;

                VBox card = buildNotificationCard(notifId, message, type, status, isRead, createdAt);
                notificationsContainer.getChildren().add(card);
            }

            if (!hasAny) {
                Label empty = new Label("🔔 No notifications yet.");
                empty.setStyle("-fx-font-size: 16px; -fx-text-fill: #999; -fx-padding: 40;");
                notificationsContainer.getChildren().add(empty);
            }

        } catch (SQLException e) {
            System.err.println("[NotificationsController] Load error: " + e.getMessage());
        }

        // Update unread badge
        int finalUnread = unread;
        Platform.runLater(() -> {
            if (unreadCountLabel != null) {
                unreadCountLabel.setText(finalUnread > 0
                        ? finalUnread + " unread"
                        : "All read ✓");
                unreadCountLabel.setStyle(finalUnread > 0
                        ? "-fx-text-fill: #e53e3e; -fx-font-weight: bold;"
                        : "-fx-text-fill: #4caf50; -fx-font-weight: bold;");
            }
        });
    }

    private VBox buildNotificationCard(int notifId, String message, String type,
                                       String status, boolean isRead, Timestamp createdAt) {
        VBox card = new VBox(8);
        card.setPadding(new Insets(15, 20, 15, 20));
        card.setStyle(
                "-fx-background-color: " + (isRead ? "#ffffff" : "#f0f7ff") + ";"
                        + "-fx-border-color: " + (isRead ? "#e0e0e0" : "#2196f3") + ";"
                        + "-fx-border-width: 1 1 1 4;"
                        + "-fx-border-radius: 8;"
                        + "-fx-background-radius: 8;"
                        + "-fx-cursor: hand;"
        );
        card.setMargin(card, new Insets(0, 0, 8, 0));

        // Top row: type icon + time
        HBox topRow = new HBox(10);
        topRow.setAlignment(javafx.geometry.Pos.CENTER_LEFT);

        String icon = getTypeIcon(type);
        Label typeLabel = new Label(icon + " " + formatType(type));
        typeLabel.setStyle("-fx-font-size: 12px; -fx-font-weight: bold; -fx-text-fill: #555;");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label timeLabel = new Label(createdAt != null
                ? createdAt.toLocalDateTime().format(DATE_FMT) : "");
        timeLabel.setStyle("-fx-font-size: 11px; -fx-text-fill: #999;");

        // SMS status badge
        Label statusBadge = new Label(getSmsStatusBadge(status));
        statusBadge.setStyle("-fx-font-size: 11px; -fx-padding: 2 8; -fx-background-radius: 10;"
                + "-fx-background-color: " + getStatusColor(status) + ";"
                + "-fx-text-fill: white;");

        topRow.getChildren().addAll(typeLabel, spacer, statusBadge, timeLabel);

        // Message
        Label msgLabel = new Label(message);
        msgLabel.setWrapText(true);
        msgLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #333;");

        // Unread dot
        if (!isRead) {
            Label dot = new Label("● NEW");
            dot.setStyle("-fx-font-size: 10px; -fx-text-fill: #2196f3; -fx-font-weight: bold;");
            card.getChildren().addAll(topRow, msgLabel, dot);
        } else {
            card.getChildren().addAll(topRow, msgLabel);
        }

        // Mark as read on click
        card.setOnMouseClicked(e -> {
            notificationService.markAsRead(notifId);
            card.setStyle(card.getStyle()
                    .replace("#f0f7ff", "#ffffff")
                    .replace("#2196f3", "#e0e0e0"));
        });

        return card;
    }

    private String getTypeIcon(String type) {
        if (type == null) return "🔔";
        return switch (type) {
            case "EVENT_CREATED"        -> "🎉";
            case "EVENT_STATUS_CHANGED" -> "📢";
            case "EVENT_COMPLETED"      -> "✅";
            case "EVENT_REMINDER"       -> "⏰";
            case "DELIVERY_ASSIGNED"    -> "🚚";
            default                     -> "🔔";
        };
    }

    private String formatType(String type) {
        if (type == null) return "Notification";
        return switch (type) {
            case "EVENT_CREATED"        -> "Event Created";
            case "EVENT_STATUS_CHANGED" -> "Status Update";
            case "EVENT_COMPLETED"      -> "Completed";
            case "EVENT_REMINDER"       -> "Reminder";
            case "DELIVERY_ASSIGNED"    -> "Delivery";
            default                     -> type;
        };
    }

    private String getSmsStatusBadge(String status) {
        return switch (status == null ? "" : status) {
            case "sent"    -> "📱 SMS Sent";
            case "failed"  -> "❌ SMS Failed";
            case "pending" -> "⏳ Pending";
            default        -> "🔔 In-App";
        };
    }

    private String getStatusColor(String status) {
        return switch (status == null ? "" : status) {
            case "sent"    -> "#4caf50";
            case "failed"  -> "#f44336";
            case "pending" -> "#ff9800";
            default        -> "#9e9e9e";
        };
    }
}