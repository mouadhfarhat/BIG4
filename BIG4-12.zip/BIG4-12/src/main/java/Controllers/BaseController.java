package Controllers;

import Services.AuthService;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Popup;
import javafx.stage.Stage;

import java.io.IOException;

public class BaseController {

    @FXML protected Button aboutBtn;
    @FXML protected Button menuBtn;
    @FXML protected Button reserveBtn;
    @FXML protected Button eventsBtn;
    @FXML protected Button clientEventsBtn;
    @FXML protected Button rapportBtn;
    @FXML protected Button adminBtn;
    @FXML protected Button contactBtn;
    @FXML protected Button deliveryBtn;
    @FXML protected Button cartBtn;
    @FXML protected Button profileBtn;
    @FXML protected Button callBtn;
    @FXML protected Button logoutBtn;
    @FXML protected BorderPane rootPane;

    protected Popup deliveryPopup;
    protected Popup adminPopup;

    @FXML
    public void initialize() {
        buildAdminPopup();
        buildDeliveryPopup();
    }

    // ── Admin Popup ───────────────────────────────────────────────────────────
    private void buildAdminPopup() {
        adminPopup = new Popup();
        adminPopup.setAutoHide(true);
        adminPopup.setAutoFix(true);

        VBox card = new VBox(0);
        card.setStyle(
            "-fx-background-color: rgb(5, 14, 42);" +
            "-fx-background-radius: 14;" +
            "-fx-border-color: rgba(255,165,0,0.30);" +
            "-fx-border-width: 1;" +
            "-fx-border-radius: 14;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.60), 24, 0.25, 0, 8);" +
            "-fx-padding: 10 0 10 0;" +
            "-fx-min-width: 240;"
        );

        Label sectionLabel = new Label("A D M I N");
        sectionLabel.setStyle(
            "-fx-text-fill: #FFA500;" +
            "-fx-font-size: 9.5px;" +
            "-fx-font-family: 'Arial';" +
            "-fx-padding: 4 20 8 20;" +
            "-fx-opacity: 0.75;"
        );
        card.getChildren().add(sectionLabel);

        HBox line = new HBox();
        line.setStyle("-fx-background-color: rgba(255,165,0,0.18); -fx-pref-height: 1;");
        VBox.setMargin(line, new Insets(0, 14, 6, 14));
        card.getChildren().add(line);

        card.getChildren().addAll(
            buildAdminItem("📦", "Ingredients", "Inventory dashboard", this::openInventoryStock),
            buildAdminItem("🗑", "Waste Records", "Record and review waste", this::openInventoryWaste),
            buildAdminItem("🍽", "Menu & Dishes", "Manage menus and dishes", this::openMenuDishAdmin)
        );

        adminPopup.getContent().add(card);
    }

    private HBox buildAdminItem(String emoji, String title, String subtitle, Runnable action) {
        Label icon = new Label(emoji);
        icon.setStyle(
            "-fx-font-size: 17px;" +
            "-fx-background-color: rgba(255,165,0,0.13);" +
            "-fx-background-radius: 9;" +
            "-fx-padding: 7 9 7 9;" +
            "-fx-min-width: 38;" +
            "-fx-alignment: CENTER;"
        );

        Label titleLbl = new Label(title);
        titleLbl.setStyle(
            "-fx-text-fill: white;" +
            "-fx-font-size: 13px;" +
            "-fx-font-weight: bold;" +
            "-fx-font-family: 'Arial';"
        );
        Label subLbl = new Label(subtitle);
        subLbl.setStyle(
            "-fx-text-fill: rgba(255,255,255,0.40);" +
            "-fx-font-size: 10px;" +
            "-fx-font-family: 'Arial';"
        );
        VBox text = new VBox(2, titleLbl, subLbl);
        text.setAlignment(Pos.CENTER_LEFT);

        HBox row = new HBox(12, icon, text);
        row.setAlignment(Pos.CENTER_LEFT);
        row.setPadding(new Insets(9, 18, 9, 14));
        row.setStyle("-fx-cursor: hand; -fx-background-color: transparent; -fx-background-radius: 10;");

        row.setOnMouseEntered(e -> {
            row.setStyle("-fx-cursor: hand; -fx-background-color: rgba(255,165,0,0.09); -fx-background-radius: 10;");
            icon.setStyle(
                "-fx-font-size: 17px;" +
                "-fx-background-color: rgba(255,165,0,0.25);" +
                "-fx-background-radius: 9;" +
                "-fx-padding: 7 9 7 9;" +
                "-fx-min-width: 38;" +
                "-fx-alignment: CENTER;"
            );
            titleLbl.setStyle(
                "-fx-text-fill: #FFA500;" +
                "-fx-font-size: 13px;" +
                "-fx-font-weight: bold;" +
                "-fx-font-family: 'Arial';"
            );
        });
        row.setOnMouseExited(e -> {
            row.setStyle("-fx-cursor: hand; -fx-background-color: transparent; -fx-background-radius: 10;");
            icon.setStyle(
                "-fx-font-size: 17px;" +
                "-fx-background-color: rgba(255,165,0,0.13);" +
                "-fx-background-radius: 9;" +
                "-fx-padding: 7 9 7 9;" +
                "-fx-min-width: 38;" +
                "-fx-alignment: CENTER;"
            );
            titleLbl.setStyle(
                "-fx-text-fill: white;" +
                "-fx-font-size: 13px;" +
                "-fx-font-weight: bold;" +
                "-fx-font-family: 'Arial';"
            );
        });

        row.setOnMouseClicked(e -> {
            adminPopup.hide();
            action.run();
        });

        return row;
    }

    // ── Delivery Popup ────────────────────────────────────────────────────────
    private void buildDeliveryPopup() {
        deliveryPopup = new Popup();
        deliveryPopup.setAutoHide(true);
        deliveryPopup.setAutoFix(true);

        VBox card = new VBox(0);
        card.setStyle(
            "-fx-background-color: rgb(5, 14, 42);" +
            "-fx-background-radius: 14;" +
            "-fx-border-color: rgba(255,165,0,0.30);" +
            "-fx-border-width: 1;" +
            "-fx-border-radius: 14;" +
            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.60), 24, 0.25, 0, 8);" +
            "-fx-padding: 10 0 10 0;" +
            "-fx-min-width: 250;"
        );

        Label sectionLabel = new Label("D E L I V E R Y");
        sectionLabel.setStyle(
            "-fx-text-fill: #FFA500;" +
            "-fx-font-size: 9.5px;" +
            "-fx-font-family: 'Arial';" +
            "-fx-padding: 4 20 8 20;" +
            "-fx-opacity: 0.75;"
        );
        card.getChildren().add(sectionLabel);

        HBox line = new HBox();
        line.setStyle("-fx-background-color: rgba(255,165,0,0.18); -fx-pref-height: 1;");
        VBox.setMargin(line, new Insets(0, 14, 6, 14));
        card.getChildren().add(line);

        card.getChildren().addAll(
            buildDeliveryItem("📦", "Delivery Dashboard", "Overview & management", this::loadDeliveryDashboard),
            buildDeliveryItem("➕", "Add Delivery", "Create a new delivery", this::loadAddDelivery),
            buildDeliveryItem("🚴", "DeliveryMan View", "Driver's interface", this::loadDeliveryManView)
        );

        deliveryPopup.getContent().add(card);
    }

    private HBox buildDeliveryItem(String emoji, String title, String subtitle, Runnable action) {
        Label icon = new Label(emoji);
        icon.setStyle(
            "-fx-font-size: 17px;" +
            "-fx-background-color: rgba(255,165,0,0.13);" +
            "-fx-background-radius: 9;" +
            "-fx-padding: 7 9 7 9;" +
            "-fx-min-width: 38;" +
            "-fx-alignment: CENTER;"
        );

        Label titleLbl = new Label(title);
        titleLbl.setStyle(
            "-fx-text-fill: white;" +
            "-fx-font-size: 13px;" +
            "-fx-font-weight: bold;" +
            "-fx-font-family: 'Arial';"
        );
        Label subLbl = new Label(subtitle);
        subLbl.setStyle(
            "-fx-text-fill: rgba(255,255,255,0.40);" +
            "-fx-font-size: 10px;" +
            "-fx-font-family: 'Arial';"
        );
        VBox text = new VBox(2, titleLbl, subLbl);
        text.setAlignment(Pos.CENTER_LEFT);

        HBox row = new HBox(12, icon, text);
        row.setAlignment(Pos.CENTER_LEFT);
        row.setPadding(new Insets(9, 18, 9, 14));
        row.setStyle("-fx-cursor: hand; -fx-background-color: transparent; -fx-background-radius: 10;");

        row.setOnMouseEntered(e -> {
            row.setStyle("-fx-cursor: hand; -fx-background-color: rgba(255,165,0,0.09); -fx-background-radius: 10;");
            icon.setStyle(
                "-fx-font-size: 17px;" +
                "-fx-background-color: rgba(255,165,0,0.25);" +
                "-fx-background-radius: 9;" +
                "-fx-padding: 7 9 7 9;" +
                "-fx-min-width: 38;" +
                "-fx-alignment: CENTER;"
            );
            titleLbl.setStyle(
                "-fx-text-fill: #FFA500;" +
                "-fx-font-size: 13px;" +
                "-fx-font-weight: bold;" +
                "-fx-font-family: 'Arial';"
            );
        });
        row.setOnMouseExited(e -> {
            row.setStyle("-fx-cursor: hand; -fx-background-color: transparent; -fx-background-radius: 10;");
            icon.setStyle(
                "-fx-font-size: 17px;" +
                "-fx-background-color: rgba(255,165,0,0.13);" +
                "-fx-background-radius: 9;" +
                "-fx-padding: 7 9 7 9;" +
                "-fx-min-width: 38;" +
                "-fx-alignment: CENTER;"
            );
            titleLbl.setStyle(
                "-fx-text-fill: white;" +
                "-fx-font-size: 13px;" +
                "-fx-font-weight: bold;" +
                "-fx-font-family: 'Arial';"
            );
        });

        row.setOnMouseClicked(e -> {
            deliveryPopup.hide();
            action.run();
        });

        return row;
    }

    // ── Popup Handlers ────────────────────────────────────────────────────────
    @FXML
    protected void handleDelivery(javafx.event.ActionEvent event) {
        if (deliveryPopup.isShowing()) {
            deliveryPopup.hide();
        } else {
            javafx.geometry.Bounds bounds = deliveryBtn.localToScreen(deliveryBtn.getBoundsInLocal());
            double x = bounds.getMinX();
            double y = bounds.getMaxY() + 6;
            deliveryPopup.show(deliveryBtn.getScene().getWindow(), x, y);
        }
    }

    @FXML
    protected void handleAdmin(javafx.event.ActionEvent event) {
        if (adminPopup.isShowing()) {
            adminPopup.hide();
        } else {
            javafx.geometry.Bounds bounds = adminBtn.localToScreen(adminBtn.getBoundsInLocal());
            double x = bounds.getMinX();
            double y = bounds.getMaxY() + 6;
            adminPopup.show(adminBtn.getScene().getWindow(), x, y);
        }
    }

    // ── Navigation Methods ────────────────────────────────────────────────────
    @FXML
    protected void handleAbout(javafx.event.ActionEvent event) {
        showAlert("About", "About Big4",
                "Big4 is a high-end gastronomic restaurant.\n\n" +
                "Our mission: Where coffee excellence meets gastronomy.\n\n" +
                "We offer refined cuisine with high-quality fresh products.");
    }

    @FXML
    protected void handleMenu(javafx.event.ActionEvent event) {
        loadScene("menu.fxml", "Menu - Big4");
    }

    @FXML
    protected void handleReservations(javafx.event.ActionEvent event) {
        loadScene("reservation.fxml", "Reservations - Big4");
    }

    @FXML
    protected void handleEvents(javafx.event.ActionEvent event) {
        loadScene("food-donation-events.fxml", "Food Donation Management - Big4");
    }

    @FXML
    protected void handleClientEvents(javafx.event.ActionEvent event) {
        loadScene("client-events-calendar-api.fxml", "Client Events - Big4");
    }

    @FXML
    protected void handleRapport(javafx.event.ActionEvent event) {
        showAlert("Reports", "Our Reports",
                "Welcome to our Reports section!\n\n" +
                "Available Reports:\n" +
                "• Monthly Sales Report\n" +
                "• Customer Feedback Summary\n" +
                "• Restaurant Performance Analysis\n" +
                "• Menu Popularity Report\n\n" +
                "Reports are generated and updated regularly.");
    }

    @FXML
    protected void handleContact(javafx.event.ActionEvent event) {
        showAlert("Contact", "Contact Us",
                "Email: info@big4restaurant.com\n" +
                "Phone: +33 1 23 45 67 89\n" +
                "Address: 123 Gastronomic Street, Paris 75001\n" +
                "Website: www.big4restaurant.com");
    }

    @FXML
    protected void handleCart(javafx.event.ActionEvent event) {
        loadScene("cart.fxml", "My Cart - Big4");
    }

    @FXML
    protected void handleProfile(javafx.event.ActionEvent event) {
        loadScene("profile.fxml", "My Profile - Big4");
    }

    @FXML
    protected void handleLogout(javafx.event.ActionEvent event) {
        AuthService.logout();
        loadScene("login.fxml", "Big4 - Login");
    }

    @FXML
    protected void handleCall(javafx.event.ActionEvent event) {
        showAlert("Call Big4", "Contact Information",
                "Phone: +33 1 23 45 67 89\n\n" +
                "Business Hours:\n" +
                "Monday - Friday: 10:00 AM - 11:00 PM\n" +
                "Saturday: 11:00 AM - 12:00 AM\n" +
                "Sunday: 11:00 AM - 11:00 PM");
    }

    // ── Delivery Navigation Methods ───────────────────────────────────────────
    protected void loadDeliveryDashboard() {
        loadScene("/DeliverymanManagement.fxml", "Delivery Dashboard - Big4");
    }

    protected void openInventoryStock() {
        openInventoryAndSelectTab(false);
    }

    protected void openInventoryWaste() {
        openInventoryAndSelectTab(true);
    }

    protected void openMenuDishAdmin() {
        loadScene("/menu-management.fxml", "Menu & Dish Management - Big4");
    }

    protected void openInventoryAndSelectTab(boolean selectWasteTab) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/main-view.fxml"));
            Parent inventoryRoot = loader.load();
            MainController controller = loader.getController();
            if (selectWasteTab) {
                controller.showWasteTab();
            } else {
                controller.showStockTab();
            }
            rootPane.setCenter(inventoryRoot);
            Stage stage = (Stage) rootPane.getScene().getWindow();
            stage.setTitle(selectWasteTab ? "Waste Records - Big4" : "Inventory Dashboard - Big4");
        } catch (IOException e) {
            e.printStackTrace();
            showErrorAlert("Navigation Error", "Unable to open inventory.\n\nError: " + e.getMessage());
        }
    }

    protected void loadAddDelivery() {
        loadScene("/CreateDelivery.fxml", "Add Delivery - Big4");
    }

    protected void loadDeliveryManView() {
        loadScene("/DeliveryView.fxml", "DeliveryMan View - Big4");
    }

    // ── Utility Methods ───────────────────────────────────────────────────────
    protected void loadScene(String fxmlPath, String windowTitle) {
        try {
            String normalizedPath = fxmlPath.startsWith("/") ? fxmlPath : "/" + fxmlPath;
            java.net.URL resource = getClass().getResource(normalizedPath);
            if (resource == null) {
                throw new IOException("FXML not found: " + normalizedPath);
            }

            FXMLLoader loader = new FXMLLoader(resource);
            Parent root = loader.load();
            Stage stage = (Stage) rootPane.getScene().getWindow();
            stage.setScene(new Scene(root, 1400, 800));
            stage.setTitle(windowTitle);
            stage.setMaximized(true);
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Loading Error",
                    "Unable to load page: " + fxmlPath + "\n\n" +
                    "Error: " + e.getMessage());
        }
    }

    protected void showAlert(String title, String header, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }

    protected void showErrorAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText("Error");
        alert.setContentText(message);
        alert.showAndWait();
    }
}