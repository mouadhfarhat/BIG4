package Controllers;

import Entities.DeliveryDAO;
import Services.DeliverymanService;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import java.sql.SQLException;

public class Rating {

    @FXML private HBox     starsBox;
    @FXML private TextArea commentField;
    @FXML private Label    deliveryInfoLabel;

    private int  selectedRating = 0;
    private Long deliveryId;
    private Long deliveryManId;

    @FXML
    public void initialize() {
        buildStars();
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Build 5 interactive stars
    // ═════════════════════════════════════════════════════════════════════════

    private void buildStars() {
        for (int i = 1; i <= 5; i++) {
            Label star = new Label("\u2606"); // ☆ empty star
            star.setStyle(
                    "-fx-font-size: 42px; -fx-cursor: hand; -fx-text-fill: #ccc;"
            );
            final int rating = i;
            star.setOnMouseEntered(e -> paintStars(rating));
            star.setOnMouseExited(e  -> paintStars(selectedRating));
            star.setOnMouseClicked(e -> {
                selectedRating = rating;
                paintStars(rating);
            });
            starsBox.getChildren().add(star);
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Paint stars gold up to count
    // ═════════════════════════════════════════════════════════════════════════

    private void paintStars(int count) {
        for (int i = 0; i < starsBox.getChildren().size(); i++) {
            Label star = (Label) starsBox.getChildren().get(i);
            boolean filled = i < count;
            star.setText(filled ? "\u2605" : "\u2606"); // ★ or ☆
            star.setStyle(
                    "-fx-font-size: 42px; -fx-cursor: hand; -fx-text-fill: "
                            + (filled ? "#FFA500" : "#ccc") + ";"
            );
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Submit rating — saves to delivery table + updates driver average
    // ═════════════════════════════════════════════════════════════════════════

    @FXML
    public void submitRating() {
        if (selectedRating == 0) {
            new Alert(Alert.AlertType.WARNING,
                    "Please select a star rating before submitting!").showAndWait();
            return;
        }

        // Save rating to delivery.rating column
        DeliveryDAO.updateDeliveryRating(deliveryId, selectedRating);

        // Recalculate and update delivery_man.rating (average of all his deliveries)
        try {
            DeliverymanService svc = new DeliverymanService();
            double newAvg = DeliveryDAO.getAverageRatingForDriver(deliveryManId);
            svc.updateDeliveryManRating(deliveryManId, newAvg);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        new Alert(Alert.AlertType.INFORMATION,
                "Thank you! Delivery man rated " + selectedRating + " star(s).\n"
                        + "His overall rating has been updated.").showAndWait();

        closeWindow();
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Skip — close without rating
    // ═════════════════════════════════════════════════════════════════════════

    @FXML
    public void skipRating() {
        closeWindow();
    }

    private void closeWindow() {
        ((Stage) starsBox.getScene().getWindow()).close();
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Called from DeliveryView to pass delivery info
    // ═════════════════════════════════════════════════════════════════════════

    public void setDeliveryInfo(Long deliveryId, Long deliveryManId, String recipientName) {
        this.deliveryId    = deliveryId;
        this.deliveryManId = deliveryManId;
        if (deliveryInfoLabel != null) {
            deliveryInfoLabel.setText(
                    "Rating delivery man for order delivered to: " + recipientName
            );
        }
    }
}
