package Controllers;

import Entities.Fooddonationevent;
import Services.Fooddonationeventservice;
import Services.EventRatingService;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.*;

public class ClientEventsCalendarController extends BaseController {

    @FXML private Label monthYearLabel;
    @FXML private GridPane calendarGrid;
    @FXML private Label totalEventsLabel;
    @FXML private Label upcomingEventsLabel;
    @FXML private Label selectedDateLabel;
    @FXML private Label eventCharityLabel;
    @FXML private Label eventStatusLabel;
    @FXML private Label totalPortionsLabel;
    @FXML private Label previewEventStarsLabel;
    @FXML private Label previewEventScoreLabel;
    @FXML private Label previewFoodStarsLabel;
    @FXML private Label previewFoodScoreLabel;
    @FXML private Label previewRatingCountLabel;
    @FXML private VBox  eventDetailsPanel;
    @FXML private Button backButton;

    private Fooddonationeventservice eventService;
    private EventRatingService ratingService = new EventRatingService();
    private List<Fooddonationevent> allEvents;
    private Map<String, List<Fooddonationevent>> eventsByDate;
    private YearMonth currentMonth;
    private LocalDate selectedDate;
    private Fooddonationevent selectedEvent;
    private int selectedEventIndex = 0;

    private static final DateTimeFormatter MONTH_FMT =
            DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH);

    @FXML
    public void initialize() {
        // Call super initialize first to set up navbar popups
        super.initialize();

        try {
            eventService = new Fooddonationeventservice();
            currentMonth = YearMonth.now();
            selectedDate = LocalDate.now();
            eventsByDate = new HashMap<>();
            loadAllEvents();
            renderCalendar();
            updateStatistics();
            hideEventDetails();
        } catch (SQLException e) {
            showErrorAlert("Database Error", "Failed to load events: " + e.getMessage());
        }
    }

    private void loadAllEvents() throws SQLException {
        allEvents = eventService.getAllFoodDonationEvents();
        eventsByDate.clear();
        for (Fooddonationevent e : allEvents) {
            if (e.getEventDate() == null) continue;
            String key = e.getEventDate().toLocalDate().toString();
            eventsByDate.computeIfAbsent(key, k -> new ArrayList<>()).add(e);
        }
    }

    private void renderCalendar() {
        calendarGrid.getChildren().clear();
        monthYearLabel.setText(currentMonth.format(MONTH_FMT));

        LocalDate firstDay  = currentMonth.atDay(1);
        int       totalDays = currentMonth.lengthOfMonth();
        int       startCol  = firstDay.getDayOfWeek().getValue() - 1;

        int col = startCol, row = 0;
        for (int day = 1; day <= totalDays; day++) {
            LocalDate date = currentMonth.atDay(day);
            String    key  = date.toString();
            List<Fooddonationevent> dayEvents =
                    eventsByDate.getOrDefault(key, new ArrayList<>());
            VBox cell = buildCell(day, date, dayEvents);
            calendarGrid.add(cell, col, row);
            if (++col == 7) { col = 0; row++; }
        }
    }

    private VBox buildCell(int day, LocalDate date, List<Fooddonationevent> events) {
        boolean isToday    = date.equals(LocalDate.now());
        boolean isSelected = date.equals(selectedDate);

        VBox cell = new VBox(3);
        cell.setPadding(new Insets(6));
        cell.setAlignment(Pos.TOP_LEFT);
        cell.setMinHeight(80);

        String bg     = isSelected ? "#1565c0" : isToday ? "#e3f2fd" : "white";
        String border = isToday ? "#1976D2" : "#e0e0e0";
        cell.setStyle(
                "-fx-background-color: " + bg + ";" +
                        "-fx-border-color: " + border + ";" +
                        "-fx-border-width: " + (isToday ? "2" : "1") + ";" +
                        "-fx-cursor: hand;");

        Label dayLbl = new Label(String.valueOf(day));
        dayLbl.setFont(Font.font("System", FontWeight.BOLD, 13));
        dayLbl.setTextFill(isSelected ? Color.WHITE
                : isToday   ? Color.web("#1976D2")
                : Color.web("#333"));
        cell.getChildren().add(dayLbl);

        int shown = 0;
        for (Fooddonationevent e : events) {
            if (shown++ >= 2) break;
            Label badge = new Label("● " + truncate(e.getCharityName(), 11));
            badge.setStyle(
                    "-fx-text-fill: " + statusColor(e.getStatus()) + ";" +
                            "-fx-font-size: 10px;" +
                            "-fx-background-color: " + statusBg(e.getStatus()) + ";" +
                            "-fx-background-radius: 3; -fx-padding: 1 4 1 4;");
            cell.getChildren().add(badge);
        }
        if (events.size() > 2) {
            Label more = new Label("+" + (events.size() - 2) + " more");
            more.setStyle("-fx-text-fill: #757575; -fx-font-size: 9px;");
            cell.getChildren().add(more);
        }

        cell.setOnMouseClicked(ev -> {
            selectedDate = date;
            selectedEventIndex = 0;
            renderCalendar();
            if (!events.isEmpty()) showEventDetails(date, events);
            else hideEventDetails();
        });

        return cell;
    }

    private void showEventDetails(LocalDate date, List<Fooddonationevent> events) {
        eventDetailsPanel.setVisible(true);
        eventDetailsPanel.setManaged(true);

        selectedDateLabel.setText(
                date.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.ENGLISH) +
                        ", " + date.format(DateTimeFormatter.ofPattern("MMMM d, yyyy")));

        if (selectedEventIndex >= events.size()) selectedEventIndex = 0;

        Fooddonationevent e = events.get(selectedEventIndex);
        selectedEvent = e;

        String charityText = "🏠 " + e.getCharityName();
        if (events.size() > 1) {
            charityText += "   (" + (selectedEventIndex + 1) + " of " + events.size() + " — click to switch)";
        }
        eventCharityLabel.setText(charityText);

        if (events.size() > 1) {
            eventCharityLabel.setStyle("-fx-cursor: hand; -fx-text-fill: #1565c0; -fx-font-weight: bold;");
            eventCharityLabel.setOnMouseClicked(ev -> {
                selectedEventIndex = (selectedEventIndex + 1) % events.size();
                showEventDetails(date, events);
            });
        } else {
            eventCharityLabel.setStyle("");
            eventCharityLabel.setOnMouseClicked(null);
        }

        eventStatusLabel.setText(e.getStatus());
        eventStatusLabel.setStyle("-fx-text-fill: " + statusColor(e.getStatus()) +
                "; -fx-font-weight: bold; -fx-font-size: 13px;");
        totalPortionsLabel.setText(e.getTotalQuantity() + " items");

        int    eventId  = e.getDonationEventId();
        double avgEvent = ratingService.getAverageEventRating(eventId);
        double avgFood  = ratingService.getAverageFoodRating(eventId);
        int    count    = ratingService.getRatingCount(eventId);
        if (count == 0) {
            previewEventStarsLabel.setText("☆☆☆☆☆");
            previewEventScoreLabel.setText("No ratings");
            previewFoodStarsLabel.setText("☆☆☆☆☆");
            previewFoodScoreLabel.setText("No ratings");
            previewRatingCountLabel.setText("Be the first to rate!");
        } else {
            previewEventStarsLabel.setText(buildStarString(avgEvent));
            previewEventScoreLabel.setText(String.format("%.1f / 5.0", avgEvent));
            previewFoodStarsLabel.setText(buildStarString(avgFood));
            previewFoodScoreLabel.setText(String.format("%.1f / 5.0", avgFood));
            previewRatingCountLabel.setText(count + " review" + (count == 1 ? "" : "s"));
        }
    }

    private void hideEventDetails() {
        eventDetailsPanel.setVisible(false);
        eventDetailsPanel.setManaged(false);
    }

    private void updateStatistics() {
        if (totalEventsLabel != null)
            totalEventsLabel.setText(String.valueOf(allEvents.size()));
        long upcoming = allEvents.stream()
                .filter(e -> e.getEventDate() != null &&
                        !e.getEventDate().toLocalDate().isBefore(LocalDate.now()))
                .count();
        if (upcomingEventsLabel != null)
            upcomingEventsLabel.setText(String.valueOf(upcoming));
    }

    @FXML private void handlePrevMonth() { currentMonth = currentMonth.minusMonths(1); renderCalendar(); hideEventDetails(); }
    @FXML private void handleNextMonth() { currentMonth = currentMonth.plusMonths(1); renderCalendar(); hideEventDetails(); }
    @FXML private void handleToday()     { currentMonth = YearMonth.now(); selectedDate = LocalDate.now(); renderCalendar(); hideEventDetails(); }

    @FXML
    private void handleViewDetails() {
        if (selectedEvent == null) return;
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/event-details-page.fxml"));
            Parent root = loader.load();
            EventDetailsPageController ctrl = loader.getController();
            ctrl.setEvent(selectedEvent);
            Stage stage = (Stage) calendarGrid.getScene().getWindow();
            stage.setScene(new Scene(root, 1400, 800));
            stage.setMaximized(true);
        } catch (IOException e) {
            showErrorAlert("Navigation Error", "Could not open event details: " + e.getMessage());
        }
    }

    @FXML
    private void handleBackToHome() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/homepage.fxml"));
            Stage stage = (Stage) calendarGrid.getScene().getWindow();
            stage.setScene(new Scene(root, 1400, 800));
            stage.setMaximized(true);
        } catch (IOException e) {
            showErrorAlert("Navigation Error", "Could not return to home: " + e.getMessage());
        }
    }

    private String statusColor(String s) {
        if (s == null) return "#607d8b";
        switch (s.toUpperCase()) {
            case "COMPLETED":   return "#4CAF50";
            case "IN_PROGRESS": return "#2196F3";
            case "SCHEDULED":   return "#9C27B0";
            case "CANCELLED":   return "#f44336";
            default:            return "#FF9800";
        }
    }

    private String statusBg(String s) {
        if (s == null) return "#f5f5f5";
        switch (s.toUpperCase()) {
            case "COMPLETED":   return "#e8f5e9";
            case "IN_PROGRESS": return "#e3f2fd";
            case "SCHEDULED":   return "#f3e5f5";
            case "CANCELLED":   return "#ffebee";
            default:            return "#fff3e0";
        }
    }

    private String truncate(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max) + "…";
    }

    private String buildStarString(double avg) {
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= 5; i++) sb.append(i <= Math.round(avg) ? "★" : "☆");
        return sb.toString();
    }
}