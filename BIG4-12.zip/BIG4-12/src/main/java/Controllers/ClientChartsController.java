package Controllers;

import Entities.Fooddonationevent;
import Services.Fooddonationeventservice;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

public class ClientChartsController extends BaseController {

    @FXML private Label totalEventsLabel;
    @FXML private Label totalPortionsLabel;
    @FXML private Label charitiesLabel;
    @FXML private Label avgPortionsLabel;

    @FXML private LineChart<String, Number> donationsLineChart;
    @FXML private CategoryAxis lineChartXAxis;
    @FXML private NumberAxis lineChartYAxis;

    @FXML private PieChart statusPieChart;

    @FXML private BarChart<String, Number> charityBarChart;
    @FXML private CategoryAxis barChartXAxis;
    @FXML private NumberAxis barChartYAxis;

    @FXML private BarChart<String, Number> eventsBarChart;
    @FXML private CategoryAxis eventsBarChartXAxis;
    @FXML private NumberAxis eventsBarChartYAxis;

    @FXML private TableView<EventStats> statsTable;
    @FXML private TableColumn<EventStats, String> statsDateColumn;
    @FXML private TableColumn<EventStats, String> statsCharityColumn;
    @FXML private TableColumn<EventStats, Integer> statsPortionsColumn;
    @FXML private TableColumn<EventStats, String> statsStatusColumn;

    private Fooddonationeventservice eventService;
    private List<Fooddonationevent> allEvents;
    private ObservableList<EventStats> eventStatsList;

    // ONE color map - shared across both charts
    private final Map<String, String> charityColorMap = new HashMap<>();

    private static final String[] CHART_COLORS = {
            "#1e3a8a",  // Dark Blue
            "#10b981",  // Green
            "#f59e0b",  // Amber
            "#ef4444",  // Red
            "#8b5cf6",  // Purple
            "#06b6d4",  // Cyan
            "#f97316",  // Orange
            "#ec4899"   // Pink
    };

    private static final Map<String, String> STATUS_COLORS = new HashMap<String, String>() {{
        put("PENDING", "#f59e0b");
        put("SCHEDULED", "#1e3a8a");
        put("IN_PROGRESS", "#06b6d4");
        put("COMPLETED", "#10b981");
        put("CANCELLED", "#ef4444");
    }};

    @FXML
    public void initialize() {
        // Call super initialize first to set up navbar popups
        super.initialize();

        try {
            eventService = new Fooddonationeventservice();
            setupStatsTable();
            loadData();
        } catch (SQLException e) {
            showErrorAlert("Database Error", "Failed to load data: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // ONE getColorForCharity method
    private String getColorForCharity(String charityName) {
        if (!charityColorMap.containsKey(charityName)) {
            int index = charityColorMap.size() % CHART_COLORS.length;
            charityColorMap.put(charityName, CHART_COLORS[index]);
        }
        return charityColorMap.get(charityName);
    }

    private void loadData() throws SQLException {
        allEvents = eventService.getAllFoodDonationEvents();
        charityColorMap.clear(); // Reset so colors are consistent each load
        updateStatistics();
        populateLineChart();
        populatePieChart();
        populateCharityBarChart();
        populateEventsBarChart();
        populateStatsTable();
    }

    private void updateStatistics() {
        int totalEvents = allEvents.size();
        totalEventsLabel.setText(String.valueOf(totalEvents));

        int totalPortions = allEvents.stream()
                .mapToInt(Fooddonationevent::getTotalQuantity)
                .sum();
        totalPortionsLabel.setText(String.valueOf(totalPortions));

        long uniqueCharities = allEvents.stream()
                .map(Fooddonationevent::getCharityName)
                .distinct()
                .count();
        charitiesLabel.setText(String.valueOf(uniqueCharities));

        int avgPortions = totalEvents > 0 ? totalPortions / totalEvents : 0;
        avgPortionsLabel.setText(String.valueOf(avgPortions));
    }

    private void populateLineChart() {
        donationsLineChart.getData().clear();

        Map<String, Integer> monthlyData = new TreeMap<>();
        DateTimeFormatter monthFormatter = DateTimeFormatter.ofPattern("MMM yyyy");

        for (Fooddonationevent event : allEvents) {
            LocalDate eventDate = convertToLocalDate(event.getEventDate());
            String monthYear = eventDate.format(monthFormatter);
            monthlyData.put(monthYear,
                    monthlyData.getOrDefault(monthYear, 0) + event.getTotalQuantity());
        }

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Total Portions Donated");

        for (Map.Entry<String, Integer> entry : monthlyData.entrySet()) {
            series.getData().add(new XYChart.Data<>(entry.getKey(), entry.getValue()));
        }

        donationsLineChart.getData().add(series);
        donationsLineChart.setLegendVisible(true);
        applyLineChartStyle();
    }

    private void applyLineChartStyle() {
        donationsLineChart.setStyle("-fx-background-color: white;");
        javafx.application.Platform.runLater(() -> {
            donationsLineChart.lookupAll(".chart-series-line").forEach(node -> {
                node.setStyle("-fx-stroke: #1e3a8a; -fx-stroke-width: 3px;");
            });
            donationsLineChart.lookupAll(".chart-line-symbol").forEach(node -> {
                node.setStyle("-fx-background-color: #1e3a8a, white;");
            });
        });
    }

    private void populatePieChart() {
        statusPieChart.getData().clear();

        Map<String, Long> statusCounts = allEvents.stream()
                .collect(Collectors.groupingBy(
                        Fooddonationevent::getStatus,
                        Collectors.counting()
                ));

        for (Map.Entry<String, Long> entry : statusCounts.entrySet()) {
            PieChart.Data slice = new PieChart.Data(
                    entry.getKey() + " (" + entry.getValue() + ")",
                    entry.getValue()
            );
            statusPieChart.getData().add(slice);
        }

        javafx.application.Platform.runLater(() -> applyPieChartColors());
    }

    private void applyPieChartColors() {
        for (PieChart.Data data : statusPieChart.getData()) {
            String status = data.getName().split(" ")[0];
            String color = STATUS_COLORS.getOrDefault(status, "#6b7280");
            if (data.getNode() != null) {
                data.getNode().setStyle("-fx-pie-color: " + color + ";");
            }
        }

        javafx.application.Platform.runLater(() -> {
            statusPieChart.lookupAll(".chart-legend-item-symbol").forEach(node -> {
                Parent parent = node.getParent();
                if (parent instanceof Label) {
                    Label label = (Label) parent;
                    String status = label.getText().split(" ")[0];
                    String color = STATUS_COLORS.getOrDefault(status, "#6b7280");
                    node.setStyle("-fx-background-color: " + color + ";");
                }
            });
        });
    }

    private void populateCharityBarChart() {
        charityBarChart.getData().clear();

        Map<String, Integer> charityData = new HashMap<>();
        for (Fooddonationevent event : allEvents) {
            charityData.put(event.getCharityName(),
                    charityData.getOrDefault(event.getCharityName(), 0) + event.getTotalQuantity());
        }

        List<Map.Entry<String, Integer>> sortedCharities = charityData.entrySet().stream()
                .sorted((e1, e2) -> e2.getValue().compareTo(e1.getValue()))
                .limit(10)
                .collect(Collectors.toList());

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Total Portions");

        for (Map.Entry<String, Integer> entry : sortedCharities) {
            series.getData().add(new XYChart.Data<>(entry.getKey(), entry.getValue()));
        }

        charityBarChart.getData().add(series);
        charityBarChart.setLegendVisible(false);
        applyBarChartColors(series);
    }

    private void populateEventsBarChart() {
        eventsBarChart.getData().clear();

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Portions");

        List<Fooddonationevent> recentEvents = allEvents.stream()
                .sorted((e1, e2) -> e2.getEventDate().compareTo(e1.getEventDate()))
                .limit(15)
                .collect(Collectors.toList());

        Collections.reverse(recentEvents);

        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MM/dd");

        for (Fooddonationevent event : recentEvents) {
            LocalDate eventDate = convertToLocalDate(event.getEventDate());
            String label = eventDate.format(dateFormatter) + " - " +
                    truncate(event.getCharityName(), 15);
            series.getData().add(new XYChart.Data<>(label, event.getTotalQuantity()));
        }

        eventsBarChart.getData().add(series);
        eventsBarChart.setLegendVisible(false);
        applyBarChartColors(series);
    }

    // ONE applyBarChartColors - uses charity name for consistent colors
    private void applyBarChartColors(XYChart.Series<String, Number> series) {
        for (XYChart.Data<String, Number> data : series.getData()) {
            String label = data.getXValue();
            String charityName = label.contains(" - ") ? label.split(" - ", 2)[1] : label;
            String color = getColorForCharity(charityName);
            data.getNode().setStyle("-fx-bar-fill: " + color + ";");
        }
    }

    private void setupStatsTable() {
        statsDateColumn.setCellValueFactory(cellData ->
                new javafx.beans.property.SimpleStringProperty(cellData.getValue().getDate()));
        statsCharityColumn.setCellValueFactory(cellData ->
                new javafx.beans.property.SimpleStringProperty(cellData.getValue().getCharity()));
        statsPortionsColumn.setCellValueFactory(cellData ->
                new javafx.beans.property.SimpleObjectProperty<>(cellData.getValue().getPortions()));
        statsStatusColumn.setCellValueFactory(cellData ->
                new javafx.beans.property.SimpleStringProperty(cellData.getValue().getStatus()));
    }

    private void populateStatsTable() {
        List<EventStats> statsList = new ArrayList<>();
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

        for (Fooddonationevent event : allEvents) {
            LocalDate eventDate = convertToLocalDate(event.getEventDate());
            statsList.add(new EventStats(
                    eventDate.format(dateFormatter),
                    event.getCharityName(),
                    event.getTotalQuantity(),
                    event.getStatus()
            ));
        }

        statsList.sort((s1, s2) -> s2.getDate().compareTo(s1.getDate()));
        eventStatsList = FXCollections.observableArrayList(statsList);
        statsTable.setItems(eventStatsList);
    }

    @FXML
    private void handleGenerateReport() {
        try {
            // Calculate stats to pass to AI report
            int totalEventsCount = allEvents.size();
            int totalPortions = allEvents.stream().mapToInt(Fooddonationevent::getTotalQuantity).sum();
            long uniqueCharities = allEvents.stream().map(Fooddonationevent::getCharityName).distinct().count();
            int avgPortions = totalEventsCount > 0 ? totalPortions / totalEventsCount : 0;

            // Find top charity
            Map<String, Integer> charityData = new HashMap<>();
            for (Fooddonationevent event : allEvents) {
                charityData.put(event.getCharityName(),
                        charityData.getOrDefault(event.getCharityName(), 0) + event.getTotalQuantity());
            }
            String topCharity = charityData.entrySet().stream()
                    .max(Map.Entry.comparingByValue())
                    .map(Map.Entry::getKey).orElse("N/A");
            int topCharityPortions = charityData.getOrDefault(topCharity, 0);

            // Status counts
            long pendingCount   = allEvents.stream().filter(e -> "PENDING".equalsIgnoreCase(e.getStatus())).count();
            long completedCount = allEvents.stream().filter(e -> "COMPLETED".equalsIgnoreCase(e.getStatus())).count();
            long cancelledCount = allEvents.stream().filter(e -> "CANCELLED".equalsIgnoreCase(e.getStatus())).count();
            long scheduledCount = allEvents.stream().filter(e -> "SCHEDULED".equalsIgnoreCase(e.getStatus())).count();

            String month = java.time.YearMonth.now()
                    .format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH));

            // Open AI report window
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/ai-report.fxml"));
            Parent root = loader.load();
            AiReportController ctrl = loader.getController();
            ctrl.setStats(totalEventsCount, totalPortions, uniqueCharities, avgPortions,
                    topCharity, topCharityPortions,
                    pendingCount, completedCount, cancelledCount, scheduledCount, month);

            Stage reportStage = new Stage();
            reportStage.setTitle("🤖 AI Donation Report - BIG4");
            reportStage.setScene(new Scene(root));
            reportStage.setResizable(true);
            reportStage.initOwner(totalEventsLabel.getScene().getWindow());
            reportStage.show();

        } catch (Exception e) {
            showErrorAlert("Error", "Could not open AI report: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleRefreshCharts() {
        try {
            loadData();
            showInfo("Charts refreshed successfully!");
        } catch (SQLException e) {
            showErrorAlert("Error", "Failed to refresh charts: " + e.getMessage());
        }
    }

    @FXML
    private void handleBackToHome() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/food-donation-events.fxml"));
            Stage stage = (Stage) totalEventsLabel.getScene().getWindow();
            stage.setScene(new Scene(root, 1400, 800));
            stage.setTitle("Food Donation Management - Big4");
            stage.setMaximized(true);
            stage.show();
        } catch (IOException e) {
            showErrorAlert("Navigation Error", "Could not return to home: " + e.getMessage());
        }
    }

    private LocalDate convertToLocalDate(java.sql.Date sqlDate) {
        return sqlDate != null ? sqlDate.toLocalDate() : LocalDate.now();
    }

    private String truncate(String text, int maxLength) {
        return text.length() > maxLength ? text.substring(0, maxLength) + "..." : text;
    }

    private void showInfo(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static class EventStats {
        private String date;
        private String charity;
        private Integer portions;
        private String status;

        public EventStats(String date, String charity, Integer portions, String status) {
            this.date = date;
            this.charity = charity;
            this.portions = portions;
            this.status = status;
        }

        public String getDate() { return date; }
        public String getCharity() { return charity; }
        public Integer getPortions() { return portions; }
        public String getStatus() { return status; }
    }
}