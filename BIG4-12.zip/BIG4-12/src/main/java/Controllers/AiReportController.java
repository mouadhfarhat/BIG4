package Controllers;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * AI Report Controller
 * Uses GitHub Models (free) to call GPT-4o-mini and generate
 * a smart natural language summary of food donation statistics.
 */
public class AiReportController {

    @FXML private Label titleLabel;
    @FXML private TextArea reportTextArea;
    @FXML private Button generateButton;
    @FXML private Button closeButton;
    @FXML private ProgressIndicator loadingIndicator;
    @FXML private Label statusLabel;
    @FXML private Label statsPreviewLabel;

    // GitHub Models - Free GPT-4o access
    private static final String API_KEY = io.github.cdimascio.dotenv.Dotenv.load().get("GITHUB_TOKEN");
    private static final String API_URL = "https://models.inference.ai.azure.com/chat/completions";
    private static final String MODEL   = "gpt-4o-mini";

    // Stats
    private int    totalEvents;
    private int    totalPortions;
    private long   uniqueCharities;
    private int    avgPortions;
    private String topCharity;
    private int    topCharityPortions;
    private long   pendingCount;
    private long   completedCount;
    private long   cancelledCount;
    private long   scheduledCount;
    private String currentMonth;

    public void setStats(int totalEvents, int totalPortions, long uniqueCharities,
                         int avgPortions, String topCharity, int topCharityPortions,
                         long pendingCount, long completedCount,
                         long cancelledCount, long scheduledCount, String currentMonth) {
        this.totalEvents        = totalEvents;
        this.totalPortions      = totalPortions;
        this.uniqueCharities    = uniqueCharities;
        this.avgPortions        = avgPortions;
        this.topCharity         = topCharity;
        this.topCharityPortions = topCharityPortions;
        this.pendingCount       = pendingCount;
        this.completedCount     = completedCount;
        this.cancelledCount     = cancelledCount;
        this.scheduledCount     = scheduledCount;
        this.currentMonth       = currentMonth;

        statsPreviewLabel.setText(
                "📊 " + totalEvents + " events  |  🍽️ " + totalPortions + " portions  |  " +
                        "🏛️ " + uniqueCharities + " charities  |  🏆 Top: " + topCharity
        );
    }

    @FXML
    public void initialize() {
        reportTextArea.setEditable(false);
        reportTextArea.setWrapText(true);
        loadingIndicator.setVisible(false);
        statusLabel.setText("");
        reportTextArea.setText(
                "Click \"✨ Generate AI Report\" to get a smart analysis of your donation statistics.\n\n" +
                        "The AI will analyze your data and provide:\n" +
                        "  • Performance summary\n" +
                        "  • Key highlights\n" +
                        "  • Actionable recommendations"
        );
    }

    @FXML
    private void handleGenerate() {
        generateButton.setDisable(true);
        loadingIndicator.setVisible(true);
        statusLabel.setText("🤖 GPT-4o is analyzing your data...");
        statusLabel.setStyle("-fx-text-fill: #555; -fx-font-style: italic;");
        reportTextArea.setText("");

        Thread thread = new Thread(() -> {
            try {
                String prompt = buildPrompt();
                String report = callGitHubModelsAPI(prompt);

                Platform.runLater(() -> {
                    reportTextArea.setText(report);
                    loadingIndicator.setVisible(false);
                    generateButton.setDisable(false);
                    statusLabel.setText("✅ AI Report generated successfully!");
                    statusLabel.setStyle("-fx-text-fill: #4CAF50; -fx-font-weight: bold;");
                });

            } catch (Exception e) {
                Platform.runLater(() -> {
                    reportTextArea.setText("❌ Failed to generate report.\n\nError: " + e.getMessage());
                    loadingIndicator.setVisible(false);
                    generateButton.setDisable(false);
                    statusLabel.setText("❌ Error occurred");
                    statusLabel.setStyle("-fx-text-fill: #f44336;");
                });
            }
        });
        thread.setDaemon(true);
        thread.start();
    }

    private String buildPrompt() {
        double completedPct = totalEvents > 0 ? (completedCount * 100.0 / totalEvents) : 0;
        double cancelledPct = totalEvents > 0 ? (cancelledCount * 100.0 / totalEvents) : 0;
        double pendingPct   = totalEvents > 0 ? (pendingCount   * 100.0 / totalEvents) : 0;

        return "You are a data analyst for BIG4, a restaurant that organizes food donation events to local charities. " +
                "Analyze the following donation statistics and write a professional report in exactly 3 sections with these exact headers:\n\n" +
                "### PERFORMANCE SUMMARY\n" +
                "### KEY HIGHLIGHTS\n" +
                "### RECOMMENDATIONS\n\n" +
                "Keep it under 250 words, professional but friendly. Use bullet points with - for lists.\n\n" +
                "DATA:\n" +
                "- Period: " + currentMonth + "\n" +
                "- Total donation events: " + totalEvents + "\n" +
                "- Total food portions donated: " + totalPortions + "\n" +
                "- Charities served: " + uniqueCharities + "\n" +
                "- Average portions per event: " + avgPortions + "\n" +
                "- Top charity: " + topCharity + " (" + topCharityPortions + " portions)\n" +
                "- COMPLETED: " + completedCount + " (" + String.format("%.0f", completedPct) + "%)\n" +
                "- PENDING: "   + pendingCount   + " (" + String.format("%.0f", pendingPct)   + "%)\n" +
                "- SCHEDULED: " + scheduledCount + "\n" +
                "- CANCELLED: " + cancelledCount + " (" + String.format("%.0f", cancelledPct) + "%)";
    }

    private String callGitHubModelsAPI(String prompt) throws Exception {
        URL url = new URL(API_URL);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Authorization", "Bearer " + API_KEY);
        conn.setDoOutput(true);
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(30000);

        String body = "{" +
                "\"model\":\"" + MODEL + "\"," +
                "\"max_tokens\":600," +
                "\"messages\":[" +
                "{\"role\":\"system\",\"content\":\"You are a professional data analyst. Always use exactly the section headers provided.\"}," +
                "{\"role\":\"user\",\"content\":" + toJsonString(prompt) + "}" +
                "]}";

        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.getBytes(StandardCharsets.UTF_8));
        }

        int code = conn.getResponseCode();
        InputStream is = code == 200 ? conn.getInputStream() : conn.getErrorStream();
        StringBuilder response = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) response.append(line).append("\n");
        }

        if (code != 200) throw new Exception("API returned " + code + ": " + response);
        return cleanMarkdown(parseOpenAIResponse(response.toString()));
    }

    /** Parses OpenAI-format: {"choices":[{"message":{"content":"..."}}]} */
    private String parseOpenAIResponse(String json) {
        String marker = "\"content\":\"";
        int start = json.indexOf(marker);
        if (start == -1) { marker = "\"content\": \""; start = json.indexOf(marker); }
        if (start == -1) throw new RuntimeException("Cannot parse response: " + json);

        start += marker.length();
        StringBuilder result = new StringBuilder();
        boolean escaped = false;
        for (int i = start; i < json.length(); i++) {
            char c = json.charAt(i);
            if (escaped) {
                if      (c == 'n') result.append('\n');
                else if (c == 't') result.append('\t');
                else if (c == '"') result.append('"');
                else if (c == '\\') result.append('\\');
                else result.append(c);
                escaped = false;
            } else if (c == '\\') { escaped = true;
            } else if (c == '"')  { break;
            } else                { result.append(c); }
        }
        return result.toString().trim();
    }

    /** Converts markdown to clean readable plain text for JavaFX TextArea */
    private String cleanMarkdown(String text) {
        return text
                .replaceAll("###\\s*(PERFORMANCE SUMMARY[^\n]*)", "\n📋  PERFORMANCE SUMMARY\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                .replaceAll("###\\s*(KEY HIGHLIGHTS?[^\n]*)",     "\n🏆  KEY HIGHLIGHTS\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                .replaceAll("###\\s*(RECOMMENDATIONS?[^\n]*)",    "\n💡  RECOMMENDATIONS\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                .replaceAll("###\\s*(.+)",                        "\n📌  $1\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                .replaceAll("\\*\\*(.+?)\\*\\*", "$1")
                .replaceAll("(?m)^-\\s+", "  •  ")
                .replaceAll("\n{3,}", "\n\n")
                .trim();
    }

    private String toJsonString(String text) {
        return "\"" + text
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t") + "\"";
    }

    @FXML
    private void handleClose() {
        ((Stage) closeButton.getScene().getWindow()).close();
    }
}