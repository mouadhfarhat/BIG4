package Controllers;

import Services.AuthService;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class DeliveryManagementHubController {

    @FXML private Button navDeliveryBtn;
    @FXML private Button navDeliverymanBtn;
    @FXML private Label pageTitle;
    @FXML private Label breadcrumb;
    @FXML private StackPane contentArea;

    // Active nav style (highlighted)
    private static final String ACTIVE_STYLE =
            "-fx-background-color: rgba(245,166,35,0.18); " +
                    "-fx-text-fill: #F5A623; " +
                    "-fx-font-size: 14px; " +
                    "-fx-font-weight: bold; " +
                    "-fx-padding: 14 18; " +
                    "-fx-background-radius: 10; " +
                    "-fx-cursor: hand; " +
                    "-fx-alignment: CENTER_LEFT; " +
                    "-fx-border-color: rgba(245,166,35,0.40); " +
                    "-fx-border-width: 1; " +
                    "-fx-border-radius: 10;";

    // Inactive nav style
    private static final String INACTIVE_STYLE =
            "-fx-background-color: transparent; " +
                    "-fx-text-fill: rgba(245,240,232,0.75); " +
                    "-fx-font-size: 14px; " +
                    "-fx-padding: 14 18; " +
                    "-fx-background-radius: 10; " +
                    "-fx-cursor: hand; " +
                    "-fx-alignment: CENTER_LEFT;";

    @FXML
    public void initialize() {
        // Load the default section (Delivery Management) on startup
        handleNavDelivery();
    }

    @FXML
    private void handleNavDelivery() {
        setActiveButton(navDeliveryBtn);
        pageTitle.setText("Delivery Management");
        breadcrumb.setText("Dashboard › Delivery › Delivery Mgmt");
        loadContent("/AdminDelivery.fxml");
    }

    @FXML
    private void handleNavDeliveryman() {
        setActiveButton(navDeliverymanBtn);
        pageTitle.setText("Deliveryman Management");
        breadcrumb.setText("Dashboard › Delivery › Deliveryman Mgmt");
        loadContent("/DeliverymanManagement.fxml");
    }

    @FXML
    private void handleBackToDashboard() {
        // Print all available FXMLs to find the right name
        System.out.println(getClass().getResource("/mainadmindashboard.fxml"));      // null = not found
        System.out.println(getClass().getResource("/MainAdminDashboard.fxml"));      // null = not found
        System.out.println(getClass().getResource("/mainAdminDashboard.fxml"));      // non-null = found!
        navigateTo("/styles/mainadmindashboard.fxml", "Admin Dashboard - Big4", 1250, 800);
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private void loadContent(String fxmlPath) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Node content = loader.load();
            contentArea.getChildren().setAll(content);
        } catch (Exception e) {
            showError("Could not load view: " + fxmlPath + "\n" + e.getMessage());
            e.printStackTrace();
        }
    }

    private void setActiveButton(Button active) {
        navDeliveryBtn.setStyle(INACTIVE_STYLE);
        navDeliverymanBtn.setStyle(INACTIVE_STYLE);
        active.setStyle(ACTIVE_STYLE);
    }

    private void navigateTo(String fxmlPath, String title, int w, int h) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource(fxmlPath));
            Stage stage = (Stage) contentArea.getScene().getWindow();
            stage.setScene(new Scene(root, w, h));
            stage.setTitle(title);
        } catch (Exception e) {
            showError("Could not navigate to: " + fxmlPath + "\n" + e.getMessage());
            e.printStackTrace();
        }
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Navigation Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}