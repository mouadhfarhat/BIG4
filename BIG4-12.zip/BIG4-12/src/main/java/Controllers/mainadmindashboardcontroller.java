package Controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.scene.Node;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class mainadmindashboardcontroller implements Initializable {

    @FXML private Button homeBtn;
    @FXML private Button logoutBtn;
    @FXML private Button userManagementBtn;
    @FXML private Button menuDishesBtn;
    @FXML private Button reservationOrderingBtn;
    @FXML private Button deliveryManagementBtn;
    @FXML private Button eventsManagementBtn;
    @FXML private Button ingredientWasteBtn;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // nothing to initialize for now
    }

    private void navigateTo(String fxmlPath, ActionEvent event) {
        try {
            URL location = getClass().getResource("/" + fxmlPath);
            if (location == null) {
                showError("FXML file not found: " + fxmlPath
                        + "\nMake sure the file exists in src/main/resources/");
                return;
            }
            FXMLLoader loader = new FXMLLoader(location);
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            showError("Could not open screen:\n" + e.getMessage());
            e.printStackTrace();
        }
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Navigation Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // ── Button Handlers ───────────────────────────────────────────────────────

    @FXML
    private void handleHomePage(ActionEvent event) {
        navigateTo("homepage.fxml", event);
    }

    @FXML
    private void handleLogout(ActionEvent event) {
        Services.AuthService.logout();
        navigateTo("login.fxml", event);
    }

    @FXML
    private void handleUserManagement(ActionEvent event) {
        navigateTo("UserManagement.fxml", event);
    }

    @FXML
    private void handleMenuDishes(ActionEvent event) {
        navigateTo("MenuDishesManagement.fxml", event);
    }

    @FXML
    private void handleReservationOrdering(ActionEvent event) {
        navigateTo("ReservationOrderingHub.fxml", event);
    }

    @FXML
    private void handleDeliveryManagement(ActionEvent event) {
        navigateTo("DeliveryManagementHub.fxml", event);
    }

    @FXML
    private void handleEventsManagement(ActionEvent event) {
        navigateTo("food-donation-events.fxml", event);
    }

    @FXML
    private void handleIngredientWaste(ActionEvent event) {
        navigateTo("AdminPanel.fxml", event);
    }
}