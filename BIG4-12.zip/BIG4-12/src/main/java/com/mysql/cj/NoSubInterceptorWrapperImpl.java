package com.mysql.cj;

import com.mysql.cj.interceptors.QueryInterceptor;

public class NoSubInterceptorWrapperImpl extends NoSubInterceptorWrapper {
    public NoSubInterceptorWrapperImpl(QueryInterceptor underlyingInterceptor) {
        super(underlyingInterceptor);
    }
}
