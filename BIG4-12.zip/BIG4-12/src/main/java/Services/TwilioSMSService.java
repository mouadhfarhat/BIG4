package Services;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.OutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * Twilio SMS Service
 * Sends real SMS messages via Twilio REST API (no SDK needed)
 */
public class TwilioSMSService {

    private static final String ACCOUNT_SID = io.github.cdimascio.dotenv.Dotenv.load().get("TWILIO_ACCOUNT_SID");
    private static final String AUTH_TOKEN   = io.github.cdimascio.dotenv.Dotenv.load().get("TWILIO_AUTH_TOKEN");
    private static final String FROM_NUMBER  = io.github.cdimascio.dotenv.Dotenv.load().get("TWILIO_FROM_NUMBER");

    private static final String API_URL =
            "https://api.twilio.com/2010-04-01/Accounts/" + ACCOUNT_SID + "/Messages.json";

    // Singleton
    private static TwilioSMSService instance;
    public static TwilioSMSService getInstance() {
        if (instance == null) instance = new TwilioSMSService();
        return instance;
    }

    /**
     * Send an SMS message
     * @param toPhone  recipient phone in E.164 format e.g. "+21612345678"
     * @param message  text body (max ~1600 chars)
     * @return true if sent successfully
     */
    public boolean sendSMS(String toPhone, String message) {
        if (toPhone == null || toPhone.isBlank()) {
            System.err.println("[SMS] Cannot send — phone number is empty");
            return false;
        }

        try {
            // Build POST body
            String body = "To="    + URLEncoder.encode(toPhone,  StandardCharsets.UTF_8)
                        + "&From=" + URLEncoder.encode(FROM_NUMBER, StandardCharsets.UTF_8)
                        + "&Body=" + URLEncoder.encode(message,  StandardCharsets.UTF_8);

            URL url = new URL(API_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

            // Basic Auth
            String credentials = ACCOUNT_SID + ":" + AUTH_TOKEN;
            String encoded = Base64.getEncoder().encodeToString(
                    credentials.getBytes(StandardCharsets.UTF_8));
            conn.setRequestProperty("Authorization", "Basic " + encoded);

            // Write body
            try (OutputStream os = conn.getOutputStream()) {
                os.write(body.getBytes(StandardCharsets.UTF_8));
            }

            int responseCode = conn.getResponseCode();

            // Read response
            BufferedReader reader;
            if (responseCode >= 200 && responseCode < 300) {
                reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                System.out.println("[SMS] ✅ Sent to " + toPhone + " | HTTP " + responseCode);
                reader.close();
                return true;
            } else {
                reader = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
                StringBuilder errorBody = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) errorBody.append(line);
                reader.close();
                System.err.println("[SMS] ❌ Failed to " + toPhone + " | HTTP " + responseCode
                        + " | " + errorBody);
                return false;
            }

        } catch (Exception e) {
            System.err.println("[SMS] ❌ Exception: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    // ── Convenience message builders ──────────────────────────────────────────

    public boolean sendEventCreated(String toPhone, String eventDate, String charityName) {
        String msg = "🍽️ Food Donation Event Confirmed!\n"
                   + "Date: " + eventDate + "\n"
                   + "Charity: " + charityName + "\n"
                   + "Thank you for your generosity! 💚";
        return sendSMS(toPhone, msg);
    }

    public boolean sendEventStatusChanged(String toPhone, String eventDate,
                                          String charityName, String newStatus) {
        String emoji = switch (newStatus.toLowerCase()) {
            case "approved"   -> "✅";
            case "rejected"   -> "❌";
            case "in_progress"-> "🔄";
            case "completed"  -> "🎉";
            case "cancelled"  -> "🚫";
            default           -> "📢";
        };
        String msg = emoji + " Event Update\n"
                   + "Date: " + eventDate + "\n"
                   + "Charity: " + charityName + "\n"
                   + "New Status: " + newStatus.toUpperCase() + "\n"
                   + "Visit the app for details.";
        return sendSMS(toPhone, msg);
    }

    public boolean sendEventCompleted(String toPhone, String eventDate,
                                      String charityName, int portions) {
        String msg = "🎉 Event Completed!\n"
                   + "Date: " + eventDate + "\n"
                   + "Charity: " + charityName + "\n"
                   + "Portions donated: " + portions + "\n"
                   + "You made a difference today! 💚";
        return sendSMS(toPhone, msg);
    }

    public boolean sendEventReminder(String toPhone, String eventDate,
                                     String charityName, int hoursUntil) {
        String msg = "⏰ Reminder: Food Donation Tomorrow!\n"
                   + "Date: " + eventDate + "\n"
                   + "Charity: " + charityName + "\n"
                   + "In " + hoursUntil + " hours — don't forget! 🍽️";
        return sendSMS(toPhone, msg);
    }

    public boolean sendDeliveryAssigned(String toPhone, String eventDate,
                                        String charityName, String deliveryManName) {
        String msg = "🚚 Delivery Assigned\n"
                   + "Event: " + eventDate + "\n"
                   + "Charity: " + charityName + "\n"
                   + "Delivery by: " + deliveryManName + "\n"
                   + "Track in the app.";
        return sendSMS(toPhone, msg);
    }
}
