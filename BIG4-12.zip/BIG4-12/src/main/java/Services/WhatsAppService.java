package Services;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import io.github.cdimascio.dotenv.Dotenv;


public class WhatsAppService {
    static Dotenv dotenv = Dotenv.load();
    static String ACCOUNT_SID = dotenv.get("TWILIO_ACCOUNT_SID");
    static String AUTH_TOKEN  = dotenv.get("TWILIO_AUTH_TOKEN");
    static String FROM_NUMBER       = dotenv.get("TWILIO_PHONE");

    public static void sendMessage(String toPhone, String messageBody) {
        new Thread(() -> {
            try {
                Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
                String formattedPhone = formatPhone(toPhone);
                // TESTING
                System.out.println("=== WHATSAPP DEBUG ===");
                System.out.println("TO: " + formattedPhone);
                System.out.println("FROM: " + FROM_NUMBER);
                System.out.println("SID: " + ACCOUNT_SID);
                System.out.println("MESSAGE: " + messageBody);
                //
                Message message = Message.creator(
                        new PhoneNumber(formattedPhone),
                        new PhoneNumber(FROM_NUMBER),
                        messageBody
                ).create();
                System.out.println("WhatsApp sent! SID: " + message.getSid());
            } catch (Exception e) {
                System.out.println("WhatsApp failed: " + e.getMessage());
            }
        }).start();
    }

    public static void notifyDeliveryAssigned(String phone, String driverName, int eta) {
        sendMessage(phone,
                "*Big4 Restaurant*\n\n" +
                        "Your delivery has been assigned!\n\n" +
                        "Driver: " + driverName + "\n" +
                        "Estimated arrival: " + eta + " minutes\n\n" +
                        "Thank you for ordering from Big4!"
        );
    }

    public static void notifyStatusChange(String phone, String status) {
        sendMessage(phone,
                "*Big4 Restaurant*\n\n" +
                        "Your delivery is now ON THE WAY!\n\n" +
                        "Your order is heading to you. Please be ready.\n\n" +
                        "Thank you for choosing Big4!"
        );
    }

    public static void notifyDelivered(String phone, String recipientName) {
        sendMessage(phone,
                "*Big4 Restaurant*\n\n" +
                        "Delivered successfully!\n\n" +
                        "Hello " + recipientName + ", your order has been delivered.\n\n" +
                        "Enjoy your meal!"
        );
    }

    public static void notifyWeatherDelay(String phone, int extraMinutes) {
        sendMessage(phone,
                "*Big4 Restaurant*\n\n" +
                        "Weather Alert\n\n" +
                        "Due to bad weather, your delivery will be delayed by " +
                        extraMinutes + " extra minutes.\n\n" +
                        "We apologize for the inconvenience!"
        );
    }

    private static String formatPhone(String phone) {
        String digits = phone.replaceAll("[^0-9]", "");
        if (digits.startsWith("00216")) {
            digits = digits.substring(2);
        } else if (!digits.startsWith("216")) {
            digits = "216" + digits;
        }
        return "whatsapp:+" + digits;
    }
}
