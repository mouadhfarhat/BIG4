package Services;

import Entities.Delivery;
import Utils.Mydatabase;
import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class DeliveryService {

    /**
     * Create a new delivery with auto-assignment of delivery man
     */
    public boolean addDeliveryWithAutoAssignment(Delivery delivery) throws SQLException {
        String sql = "INSERT INTO delivery (order_id, delivery_man_id, recipient_name, recipient_phone, " +
                "delivery_address, pickup_location, status, scheduled_date, estimated_time, delivery_notes) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = Mydatabase.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setLong(1, delivery.getOrderId());
            stmt.setObject(2, delivery.getDeliveryManId());
            stmt.setString(3, delivery.getRecipientName());
            stmt.setString(4, delivery.getRecipientPhone());
            stmt.setString(5, delivery.getDeliveryAddress());
            stmt.setString(6, delivery.getPickupLocation());
            stmt.setString(7, delivery.getStatus());
            stmt.setObject(8, delivery.getScheduledDate());
            stmt.setObject(9, delivery.getEstimatedTime());
            stmt.setString(10, delivery.getDeliveryNotes());

            int affectedRows = stmt.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        delivery.setDeliveryId(generatedKeys.getLong(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
        return false;
    }

    /**
     * Get all deliveries
     */
    public List<Delivery> getAllDeliveries() throws SQLException {
        List<Delivery> deliveries = new ArrayList<>();
        String sql = "SELECT * FROM delivery ORDER BY created_at DESC";

        try (Connection conn = Mydatabase.getInstance().getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                deliveries.add(mapResultSetToDelivery(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
        return deliveries;
    }

    /**
     * Get delivery by ID
     */
    public Delivery getDeliveryById(Long deliveryId) throws SQLException {
        String sql = "SELECT * FROM delivery WHERE delivery_id = ?";

        try (Connection conn = Mydatabase.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, deliveryId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToDelivery(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
        return null;
    }

    /**
     * Update delivery status
     */
    public boolean updateDeliveryStatus(Long deliveryId, String newStatus) throws SQLException {
        String sql = "UPDATE delivery SET status = ?, updated_at = NOW() WHERE delivery_id = ?";

        try (Connection conn = Mydatabase.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, newStatus);
            stmt.setLong(2, deliveryId);

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * Update full delivery record
     */
    public boolean updateDelivery(Delivery delivery) throws SQLException {
        String sql = "UPDATE delivery SET recipient_name = ?, recipient_phone = ?, delivery_address = ?, " +
                "pickup_location = ?, status = ?, scheduled_date = ?, estimated_time = ?, " +
                "delivery_notes = ?, delivery_man_id = ?, updated_at = NOW() WHERE delivery_id = ?";

        try (Connection conn = Mydatabase.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, delivery.getRecipientName());
            stmt.setString(2, delivery.getRecipientPhone());
            stmt.setString(3, delivery.getDeliveryAddress());
            stmt.setString(4, delivery.getPickupLocation());
            stmt.setString(5, delivery.getStatus());
            stmt.setObject(6, delivery.getScheduledDate());
            stmt.setObject(7, delivery.getEstimatedTime());
            stmt.setString(8, delivery.getDeliveryNotes());
            stmt.setObject(9, delivery.getDeliveryManId());
            stmt.setLong(10, delivery.getDeliveryId());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * Delete delivery
     */
    public boolean deleteDelivery(Long deliveryId) throws SQLException {
        String sql = "DELETE FROM delivery WHERE delivery_id = ?";

        try (Connection conn = Mydatabase.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, deliveryId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * Search deliveries by name, phone, or ID
     */
    public List<Delivery> searchDeliveries(String searchTerm) throws SQLException {
        List<Delivery> deliveries = new ArrayList<>();
        String sql = "SELECT * FROM delivery WHERE recipient_name LIKE ? OR recipient_phone LIKE ? " +
                "OR delivery_id LIKE ? ORDER BY created_at DESC";

        try (Connection conn = Mydatabase.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            String pattern = "%" + searchTerm + "%";
            stmt.setString(1, pattern);
            stmt.setString(2, pattern);
            stmt.setString(3, pattern);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    deliveries.add(mapResultSetToDelivery(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
        return deliveries;
    }

    /**
     * Get deliveries by status
     */
    public List<Delivery> getDeliveriesByStatus(String status) throws SQLException {
        List<Delivery> deliveries = new ArrayList<>();
        String sql = "SELECT * FROM delivery WHERE status = ? ORDER BY created_at DESC";

        try (Connection conn = Mydatabase.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, status);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    deliveries.add(mapResultSetToDelivery(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
        return deliveries;
    }

    /**
     * Get deliveries for a specific delivery man
     */
    public List<Delivery> getDeliveriesByDeliveryMan(Long deliveryManId) throws SQLException {
        List<Delivery> deliveries = new ArrayList<>();
        String sql = "SELECT * FROM delivery WHERE delivery_man_id = ? ORDER BY created_at DESC";

        try (Connection conn = Mydatabase.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, deliveryManId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    deliveries.add(mapResultSetToDelivery(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
        return deliveries;
    }

    /**
     * Map ResultSet to Delivery object
     */
    private Delivery mapResultSetToDelivery(ResultSet rs) throws SQLException {
        Delivery delivery = new Delivery();

        delivery.setDeliveryId(rs.getLong("delivery_id"));
        delivery.setOrderId(rs.getLong("order_id"));

        // Handle nullable delivery_man_id
        Object deliveryManObj = rs.getObject("delivery_man_id");
        if (deliveryManObj != null) {
            delivery.setDeliveryManId(((Number) deliveryManObj).longValue());
        }

        delivery.setRecipientName(rs.getString("recipient_name"));
        delivery.setRecipientPhone(rs.getString("recipient_phone"));
        delivery.setDeliveryAddress(rs.getString("delivery_address"));
        delivery.setPickupLocation(rs.getString("pickup_location"));
        delivery.setStatus(rs.getString("status"));

        // Handle nullable scheduled_date
        Timestamp scheduledTs = rs.getTimestamp("scheduled_date");
        if (scheduledTs != null) {
            delivery.setScheduledDate(scheduledTs.toLocalDateTime());
        }

        // Handle nullable actual_delivery_date
        Timestamp actualTs = rs.getTimestamp("actual_delivery_date");
        if (actualTs != null) {
            delivery.setActualDeliveryDate(actualTs.toLocalDateTime());
        }

        // Handle nullable estimated_time
        Object estimatedObj = rs.getObject("estimated_time");
        if (estimatedObj != null) {
            delivery.setEstimatedTime(((Number) estimatedObj).intValue());
        }

        // Handle nullable current_latitude
        Object latObj = rs.getObject("current_latitude");
        if (latObj != null) {
            delivery.setCurrentLatitude((BigDecimal) latObj);
        }

        // Handle nullable current_longitude
        Object longObj = rs.getObject("current_longitude");
        if (longObj != null) {
            delivery.setCurrentLongitude((BigDecimal) longObj);
        }

        delivery.setDeliveryNotes(rs.getString("delivery_notes"));

        // Handle nullable rating
        Object ratingObj = rs.getObject("rating");
        if (ratingObj != null) {
            delivery.setRating(((Number) ratingObj).intValue());
        }

        delivery.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
        delivery.setUpdatedAt(rs.getTimestamp("updated_at").toLocalDateTime());

        return delivery;
    }
}