package Services;

import Utils.Mydatabase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EventRatingService {

    private Connection cnx;

    public EventRatingService() {
        try {
            cnx = Mydatabase.getInstance().getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /** Submit a new rating */
    public boolean addRating(int eventId, int userId, int eventRating, int foodRating, String comment) {
        String sql = "INSERT INTO ratings(donation_event_id, user_id, event_rating, food_rating, comment) VALUES(?,?,?,?,?)";
        try (PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setInt(1, eventId);
            ps.setInt(2, userId);
            ps.setInt(3, eventRating);
            ps.setInt(4, foodRating);
            ps.setString(5, comment != null && !comment.isBlank() ? comment : null);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("addRating: " + e.getMessage());
            return false;
        }
    }

    /** Update an existing rating */
    public boolean updateRating(int ratingId, int eventRating, int foodRating, String comment) {
        String sql = "UPDATE ratings SET event_rating=?, food_rating=?, comment=? WHERE rating_id=?";
        try (PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setInt(1, eventRating);
            ps.setInt(2, foodRating);
            ps.setString(3, comment != null && !comment.isBlank() ? comment : null);
            ps.setInt(4, ratingId);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("updateRating: " + e.getMessage());
            return false;
        }
    }

    /** Delete a rating by ID */
    public boolean deleteRating(int ratingId) {
        String sql = "DELETE FROM ratings WHERE rating_id=?";
        try (PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setInt(1, ratingId);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            System.err.println("deleteRating: " + e.getMessage());
            return false;
        }
    }

    /** Get all ratings with comments for an event */
    public List<RatingRow> getRatingsWithComments(int eventId) {
        List<RatingRow> list = new ArrayList<>();
        String sql = "SELECT r.rating_id, r.user_id, r.event_rating, r.food_rating, r.comment, r.created_at, " +
                     "u.email as user_email " +
                     "FROM ratings r " +
                     "LEFT JOIN user u ON r.user_id = u.id " +
                     "WHERE r.donation_event_id = ? " +
                     "ORDER BY r.created_at DESC";
        try (PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setInt(1, eventId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                RatingRow row = new RatingRow();
                row.ratingId    = rs.getInt("rating_id");
                row.userId      = rs.getInt("user_id");
                row.eventRating = rs.getInt("event_rating");
                row.foodRating  = rs.getInt("food_rating");
                row.comment     = rs.getString("comment");
                row.createdAt   = rs.getString("created_at");
                row.userEmail   = rs.getString("user_email");
                list.add(row);
            }
        } catch (SQLException e) {
            System.err.println("getRatingsWithComments: " + e.getMessage());
        }
        return list;
    }

    /** Average event_rating for an event */
    public double getAverageEventRating(int eventId) {
        String sql = "SELECT AVG(event_rating) as avg FROM ratings WHERE donation_event_id = ?";
        try (PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setInt(1, eventId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getDouble("avg");
        } catch (SQLException e) {
            System.err.println("getAverageEventRating: " + e.getMessage());
        }
        return 0.0;
    }

    /** Average food_rating for an event */
    public double getAverageFoodRating(int eventId) {
        String sql = "SELECT AVG(food_rating) as avg FROM ratings WHERE donation_event_id = ?";
        try (PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setInt(1, eventId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getDouble("avg");
        } catch (SQLException e) {
            System.err.println("getAverageFoodRating: " + e.getMessage());
        }
        return 0.0;
    }

    /** Count total ratings for an event */
    public int getRatingCount(int eventId) {
        String sql = "SELECT COUNT(*) as cnt FROM ratings WHERE donation_event_id = ?";
        try (PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setInt(1, eventId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt("cnt");
        } catch (SQLException e) {
            System.err.println("getRatingCount: " + e.getMessage());
        }
        return 0;
    }

    /** Check if user already rated this event */
    public boolean hasUserRated(int eventId, int userId) {
        String sql = "SELECT COUNT(*) as cnt FROM ratings WHERE donation_event_id = ? AND user_id = ?";
        try (PreparedStatement ps = cnx.prepareStatement(sql)) {
            ps.setInt(1, eventId);
            ps.setInt(2, userId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt("cnt") > 0;
        } catch (SQLException e) {
            System.err.println("hasUserRated: " + e.getMessage());
        }
        return false;
    }

    /** Data holder for a rating row */
    public static class RatingRow {
        public int    ratingId;
        public int    userId;
        public int    eventRating;
        public int    foodRating;
        public String comment;
        public String createdAt;
        public String userEmail;
    }
}
