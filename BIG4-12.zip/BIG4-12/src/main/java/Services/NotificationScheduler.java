package Services;

import Utils.Mydatabase;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.concurrent.*;

/**
 * FIXED NotificationScheduler
 * Checks for upcoming events and sends SMS reminders
 * - 24 hours before event
 * - 2 hours before event
 */
public class NotificationScheduler {

    private static NotificationScheduler instance;
    private ScheduledExecutorService scheduler;
    private boolean isRunning = false;

    private NotificationScheduler() {
        scheduler = Executors.newScheduledThreadPool(1);
    }

    public static NotificationScheduler getInstance() {
        if (instance == null) {
            instance = new NotificationScheduler();
        }
        return instance;
    }

    /**
     * Start the scheduler - checks every hour
     */
    public void start() {
        if (isRunning) {
            return;
        }

        System.out.println("[Scheduler] ✓ Started – checking reminders every hour.");

        scheduler.scheduleAtFixedRate(() -> {
            try {
                System.out.println("[Scheduler] Checking for upcoming events... " + LocalDateTime.now());
                checkAndSendReminders();
            } catch (Exception e) {
                System.err.println("[Scheduler] Error: " + e.getMessage());
            }
        }, 0, 1, TimeUnit.HOURS);

        isRunning = true;
    }

    /**
     * Stop the scheduler
     */
    public void stop() {
        if (scheduler != null && !scheduler.isShutdown()) {
            scheduler.shutdown();
            isRunning = false;
            System.out.println("[Scheduler] ✓ Stopped");
        }
    }

    /**
     * Check for upcoming events and send reminders
     */
    private void checkAndSendReminders() {
        String sql =
                "SELECT fde.donation_event_id, fde.event_date, fde.charity_name, fde.total_quantity, " +
                        "       u.id as user_id, u.phone " +
                        "FROM food_donation_event fde " +
                        "CROSS JOIN user u " +
                        "WHERE u.phone IS NOT NULL " +
                        "  AND u.phone != '' " +
                        "  AND fde.status IN ('SCHEDULED', 'PENDING') " +
                        "  AND fde.event_date >= CURDATE()";

        try (Connection conn = Mydatabase.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            LocalDateTime now = LocalDateTime.now();

            while (rs.next()) {
                int eventId = rs.getInt("donation_event_id");
                Date eventDate = rs.getDate("event_date");
                String charityName = rs.getString("charity_name");
                int quantity = rs.getInt("total_quantity");
                int userId = rs.getInt("user_id");
                String phone = rs.getString("phone");

                LocalDateTime eventDateTime = eventDate.toLocalDate().atTime(10, 0);

                // Check if 24 hours before
                if (isWithinTimeWindow(now, eventDateTime, 24, 23)) {
                    sendOneDayReminder(userId, eventId, phone, charityName, eventDate.toString(), quantity);
                }

                // Check if 2 hours before
                if (isWithinTimeWindow(now, eventDateTime, 2, 1)) {
                    sendTwoHourReminder(userId, eventId, phone, charityName, quantity);
                }
            }

        } catch (SQLException e) {
            System.err.println("[Scheduler] DB error: " + e.getMessage());
        }
    }

    /**
     * Check if current time is within X hours before event (but not more than X+buffer hours)
     */
    private boolean isWithinTimeWindow(LocalDateTime now, LocalDateTime eventTime,
                                       int hoursBeforeMin, int hoursBeforeMax) {
        LocalDateTime minTime = eventTime.minusHours(hoursBeforeMax);
        LocalDateTime maxTime = eventTime.minusHours(hoursBeforeMin);
        return now.isAfter(minTime) && now.isBefore(maxTime);
    }

    /**
     * Send 24-hour reminder
     */
    private void sendOneDayReminder(int userId, int eventId, String phone,
                                    String charityName, String dateStr, int quantity) {
        // Check if already sent
        if (wasReminderSent(userId, eventId, "24H_REMINDER")) {
            return;
        }

        String message = String.format(
                "BIG4 Restaurant Reminder!\n" +
                        "Tomorrow: food donation event.\n" +
                        "Date: %s\n" +
                        "Charity: %s\n" +
                        "Quantity: %d items.\n" +
                        "Please be prepared!",
                dateStr, charityName, quantity
        );

        boolean sent = TwilioSMSService.getInstance().sendSMS(phone, message);

        if (sent) {
            markReminderSent(userId, eventId, "24H_REMINDER");
            System.out.println("[Scheduler] ✓ Sent 24h reminder for event " + eventId);
        }
    }

    /**
     * Send 2-hour reminder
     */
    private void sendTwoHourReminder(int userId, int eventId, String phone,
                                     String charityName, int quantity) {
        // Check if already sent
        if (wasReminderSent(userId, eventId, "2H_REMINDER")) {
            return;
        }

        String message = String.format(
                "BIG4 Restaurant Alert!\n" +
                        "Your donation event starts in 2 hours!\n" +
                        "Charity: %s\n" +
                        "Quantity: %d items.\n" +
                        "Get ready now!",
                charityName, quantity
        );

        boolean sent = TwilioSMSService.getInstance().sendSMS(phone, message);

        if (sent) {
            markReminderSent(userId, eventId, "2H_REMINDER");
            System.out.println("[Scheduler] ✓ Sent 2h reminder for event " + eventId);
        }
    }

    /**
     * Check if reminder was already sent
     */
    private boolean wasReminderSent(int userId, int eventId, String reminderType) {
        String sql = "SELECT COUNT(*) FROM notifications " +
                "WHERE user_id = ? AND donation_event_id = ? " +
                "AND message LIKE ? AND status = 'SENT'";

        try (Connection conn = Mydatabase.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ps.setInt(2, eventId);
            ps.setString(3, "%" + reminderType + "%");

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }

        } catch (SQLException e) {
            System.err.println("[Scheduler] Check reminder error: " + e.getMessage());
        }

        return false;
    }

    /**
     * Mark reminder as sent
     */
    private void markReminderSent(int userId, int eventId, String reminderType) {
        String sql = "INSERT INTO notifications " +
                "(user_id, donation_event_id, message, notification_type, status, scheduled_time) " +
                "VALUES (?, ?, ?, 'SMS', 'SENT', NOW())";

        try (Connection conn = Mydatabase.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ps.setInt(2, eventId);
            ps.setString(3, reminderType);
            ps.executeUpdate();

        } catch (SQLException e) {
            System.err.println("[Scheduler] Save reminder error: " + e.getMessage());
        }
    }
}