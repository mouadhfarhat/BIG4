package Services;

import Utils.Mydatabase;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * COMPLETE NotificationService
 * Handles sending SMS and saving notifications to database
 * Includes markAsRead and getUserNotifications methods
 */
public class NotificationService {

    private static NotificationService instance;

    private NotificationService() {}

    public static NotificationService getInstance() {
        if (instance == null) {
            instance = new NotificationService();
        }
        return instance;
    }

    /**
     * Called when a new event is created
     */
    public void onEventCreated(int userId, int eventId, String dateStr, String charityName) {
        String phone = getUserPhone(userId);
        if (phone == null) return;

        String message = String.format(
                "BIG4 Restaurant - New Donation Event!\n" +
                        "Date: %s\n" +
                        "Charity: %s\n" +
                        "Thank you for your generosity!",
                dateStr, charityName
        );

        boolean sent = TwilioSMSService.getInstance().sendSMS(phone, message);

        if (sent) {
            saveNotification(userId, eventId, message, "BOTH", "SENT");
        }
    }

    /**
     * Called when event status changes
     */
    public void onEventStatusChanged(int userId, int eventId, String dateStr,
                                     String charityName, String newStatus) {
        String phone = getUserPhone(userId);
        if (phone == null) return;

        String message = String.format(
                "BIG4 Restaurant - Event Update!\n" +
                        "Charity: %s\n" +
                        "Date: %s\n" +
                        "New Status: %s",
                charityName, dateStr, newStatus
        );

        boolean sent = TwilioSMSService.getInstance().sendSMS(phone, message);

        if (sent) {
            saveNotification(userId, eventId, message, "SMS", "SENT");
        }
    }

    /**
     * Called when event is marked as completed
     */
    public void onEventCompleted(int userId, int eventId, String dateStr,
                                 String charityName, int quantity) {
        String phone = getUserPhone(userId);
        if (phone == null) return;

        String message = String.format(
                "BIG4 Restaurant - Donation Complete!\n" +
                        "Charity: %s\n" +
                        "%d items successfully donated!\n" +
                        "Thank you for making a difference!",
                charityName, quantity
        );

        boolean sent = TwilioSMSService.getInstance().sendSMS(phone, message);

        if (sent) {
            saveNotification(userId, eventId, message, "BOTH", "SENT");
        }
    }

    /**
     * Get user phone number from database
     */
    private String getUserPhone(int userId) {
        String sql = "SELECT phone FROM user WHERE id = ?";

        try (Connection conn = Mydatabase.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String phone = rs.getString("phone");
                return (phone != null && !phone.trim().isEmpty()) ? phone : null;
            }

        } catch (SQLException e) {
            System.err.println("[Notification] Get phone error: " + e.getMessage());
        }

        return null;
    }

    /**
     * Save notification to database
     */
    private void saveNotification(int userId, int eventId, String message,
                                  String notificationType, String status) {
        String sql = "INSERT INTO notifications " +
                "(user_id, donation_event_id, message, notification_type, status, scheduled_time) " +
                "VALUES (?, ?, ?, ?, ?, NOW())";

        try (Connection conn = Mydatabase.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ps.setInt(2, eventId);
            ps.setString(3, message);
            ps.setString(4, notificationType);
            ps.setString(5, status);

            ps.executeUpdate();
            System.out.println("[Notification] ✓ Saved to database");

        } catch (SQLException e) {
            System.err.println("[Notification] DB Error: " + e.getMessage());
        }
    }

    /**
     * Mark notification as read
     */
    public void markAsRead(int notificationId) {
        String sql = "UPDATE notifications SET is_read = 1 WHERE notification_id = ?";

        try (Connection conn = Mydatabase.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, notificationId);
            ps.executeUpdate();
            System.out.println("[Notification] ✓ Marked as read: " + notificationId);

        } catch (SQLException e) {
            System.err.println("[Notification] Mark as read error: " + e.getMessage());
        }
    }

    /**
     * Get all notifications for a user
     */
    public List<NotificationData> getUserNotifications(int userId) {
        List<NotificationData> notifications = new ArrayList<>();

        String sql = "SELECT notification_id, message, notification_type, is_read, scheduled_time " +
                "FROM notifications " +
                "WHERE user_id = ? " +
                "ORDER BY scheduled_time DESC " +
                "LIMIT 50";

        try (Connection conn = Mydatabase.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                NotificationData notif = new NotificationData();
                notif.notificationId = rs.getInt("notification_id");
                notif.message = rs.getString("message");
                notif.type = rs.getString("notification_type");
                notif.isRead = rs.getBoolean("is_read");
                notif.scheduledTime = rs.getTimestamp("scheduled_time").toString();
                notifications.add(notif);
            }

        } catch (SQLException e) {
            System.err.println("[Notification] Get notifications error: " + e.getMessage());
        }

        return notifications;
    }

    /**
     * Get unread notification count
     */
    public int getUnreadCount(int userId) {
        String sql = "SELECT COUNT(*) FROM notifications " +
                "WHERE user_id = ? AND is_read = 0 " +
                "AND notification_type IN ('IN_APP', 'BOTH')";

        try (Connection conn = Mydatabase.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (SQLException e) {
            System.err.println("[Notification] Get unread count error: " + e.getMessage());
        }

        return 0;
    }

    /**
     * Mark all notifications as read for a user
     */
    public void markAllAsRead(int userId) {
        String sql = "UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0";

        try (Connection conn = Mydatabase.getInstance().getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            int count = ps.executeUpdate();
            System.out.println("[Notification] ✓ Marked " + count + " notifications as read");

        } catch (SQLException e) {
            System.err.println("[Notification] Mark all as read error: " + e.getMessage());
        }
    }

    /**
     * Inner class for notification data
     */
    public static class NotificationData {
        public int notificationId;
        public String message;
        public String type;
        public boolean isRead;
        public String scheduledTime;
    }
}